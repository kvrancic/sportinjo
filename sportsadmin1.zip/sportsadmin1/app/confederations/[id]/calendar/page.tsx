"use client"

import React, { useState, useMemo } from "react"
import { notFound } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetClose } from "@/components/ui/sheet"
import { getConfederationById, getMatchesByConfederationId, getCompetitorById, getCategoryById } from "@/lib/data"
import { formatDate } from "@/lib/utils"
import { PlusCircle, Pencil, Trash2, MapPin, CalendarIcon, Calendar, ArrowUpDown, X, Clock } from "lucide-react"
import { getTeamLogo } from "@/lib/team-logos"
import Image from "next/image"
import { TableToolbar } from "@/components/table-toolbar"
import { StatusBadge } from "@/components/status-badge"
import { CategoryBadge } from "@/components/category-badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface CalendarPageProps {
  params: {
    id: string
  }
}

export default function CalendarPage({ params }: CalendarPageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const allMatches = getMatchesByConfederationId(params.id)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCompact, setIsCompact] = useState(false)
  const [sortStatusAsc, setSortStatusAsc] = useState<boolean>(true)
  const [selectedMatch, setSelectedMatch] = useState<string | null>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)

  const toggleSortStatus = () => {
    setSortStatusAsc((prev) => !prev)
  }

  const filteredMatches = useMemo(() => {
    const result = [...allMatches]
      .filter((match) => match.status === "SCHEDULED")
      .filter((match) => {
        if (searchTerm === "") return true

        const homeTeam = getCompetitorById(match.homeCompetitorId)
        const awayTeam = getCompetitorById(match.awayCompetitorId)
        const category = getCategoryById(match.categoryId)

        return (
          (homeTeam && homeTeam.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (awayTeam && awayTeam.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (category && category.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          match.venue.toLowerCase().includes(searchTerm.toLowerCase()) ||
          formatDate(match.date).toLowerCase().includes(searchTerm.toLowerCase())
        )
      })

    result.sort((a, b) => {
      if (sortStatusAsc) {
        return a.status.localeCompare(b.status)
      } else {
        return b.status.localeCompare(a.status)
      }
    })
    return result
  }, [allMatches, searchTerm, sortStatusAsc])

  // Group matches by date for better visual organization
  const matchesByDate = useMemo(() => {
    const grouped = new Map<string, typeof filteredMatches>()

    filteredMatches.forEach((match) => {
      const dateKey = new Date(match.date).toLocaleDateString("hr-HR")
      if (!grouped.has(dateKey)) {
        grouped.set(dateKey, [])
      }
      grouped.get(dateKey)?.push(match)
    })

    return grouped
  }, [filteredMatches])

  const handleMatchClick = (matchId: string) => {
    setSelectedMatch(matchId)
    setIsDetailOpen(true)
  }

  const selectedMatchData = useMemo(() => {
    if (!selectedMatch) return null
    return allMatches.find((match) => match.id === selectedMatch) || null
  }, [selectedMatch, allMatches])

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
              <CalendarIcon className="h-6 w-6 text-amber-700" />
            </div>
            <h1 className="text-3xl font-bold">Kalendar natjecanja</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={toggleSortStatus} className="flex items-center gap-1">
              <ArrowUpDown className="h-4 w-4" />
              <span>Status {sortStatusAsc ? "↑" : "↓"}</span>
            </Button>
            <Button className="flex items-center gap-2 bg-amber-600 hover:bg-amber-700">
              <PlusCircle className="h-4 w-4" />
              <span>Dodaj događaj</span>
            </Button>
          </div>
        </div>

        <TableToolbar
          searchPlaceholder="Pretraži događaje..."
          onSearchChange={setSearchTerm}
          onCompactChange={setIsCompact}
          className="w-full"
        />

        <div className="rounded-md border bg-white">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Vrijeme</TableHead>
                <TableHead>Kategorija</TableHead>
                <TableHead>Timovi</TableHead>
                <TableHead>Lokacija</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Akcije</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMatches.length > 0 ? (
                Array.from(matchesByDate.entries()).map(([dateKey, matches], groupIndex) => (
                  <React.Fragment key={dateKey}>
                    <TableRow>
                      <TableCell colSpan={6} className="bg-muted/30 py-2">
                        <div className="font-medium flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4 text-amber-600" />
                          {dateKey}
                        </div>
                      </TableCell>
                    </TableRow>
                    {matches.map((match) => {
                      const homeTeam = getCompetitorById(match.homeCompetitorId)
                      const awayTeam = getCompetitorById(match.awayCompetitorId)
                      const category = getCategoryById(match.categoryId)
                      const matchTime = new Date(match.date).toLocaleTimeString("hr-HR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })

                      return (
                        <TableRow
                          key={match.id}
                          className="cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => handleMatchClick(match.id)}
                        >
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-base">{matchTime}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {category && <CategoryBadge name={category.name} gender={category.gender} size="sm" />}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                                <Image
                                  src={getTeamLogo(match.homeCompetitorId) || "/placeholder.svg"}
                                  alt={homeTeam?.name || ""}
                                  width={32}
                                  height={32}
                                  className="object-cover"
                                />
                              </div>
                              <span className="font-medium text-lg">vs</span>
                              <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                                <Image
                                  src={getTeamLogo(match.awayCompetitorId) || "/placeholder.svg"}
                                  alt={awayTeam?.name || ""}
                                  width={32}
                                  height={32}
                                  className="object-cover"
                                />
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3.5 w-3.5 text-rose-500" />
                              {match.venue}
                            </div>
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={match.status} size="sm" />
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  // Edit functionality would go here
                                }}
                              >
                                <Pencil className="h-4 w-4" />
                                <span className="sr-only">Uredi</span>
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  // Delete functionality would go here
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Izbriši</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </React.Fragment>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    <div className="flex flex-col items-center justify-center text-muted-foreground">
                      <Calendar className="h-8 w-8 mb-2 text-muted" />
                      <p>Nema nadolazećih događaja za prikaz.</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Event Detail Sheet */}
      <Sheet open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <SheetContent className="sm:max-w-md overflow-y-auto">
          <SheetHeader className="pb-4">
            <div className="flex justify-between items-center">
              <SheetTitle>Detalji događaja</SheetTitle>
              <SheetClose className="rounded-full h-8 w-8 flex items-center justify-center hover:bg-muted">
                <X className="h-4 w-4" />
              </SheetClose>
            </div>
            <SheetDescription>Pregledajte detalje odabranog događaja</SheetDescription>
          </SheetHeader>

          {selectedMatchData && (
            <div className="space-y-6 mt-2">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="px-3 py-1 bg-amber-50 text-amber-800 border-amber-200">
                  <CalendarIcon className="h-3.5 w-3.5 mr-1" />
                  {new Date(selectedMatchData.date).toLocaleDateString("hr-HR", {
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric",
                  })}
                </Badge>
                <Badge variant="outline" className="px-3 py-1 bg-blue-50 text-blue-800 border-blue-200">
                  <Clock className="h-3.5 w-3.5 mr-1" />
                  {new Date(selectedMatchData.date).toLocaleTimeString("hr-HR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </Badge>
              </div>

              <Card className="border-2 border-muted">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Natjecanje</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    {(() => {
                      const category = getCategoryById(selectedMatchData.categoryId)
                      return category ? <CategoryBadge name={category.name} gender={category.gender} /> : null
                    })()}
                    <StatusBadge status={selectedMatchData.status} />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-muted">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Lokacija</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-rose-500" />
                    <span className="font-medium">{selectedMatchData.venue}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-muted">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Timovi</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(() => {
                    const homeTeam = getCompetitorById(selectedMatchData.homeCompetitorId)
                    const awayTeam = getCompetitorById(selectedMatchData.awayCompetitorId)

                    return (
                      <>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-12 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                              <Image
                                src={getTeamLogo(selectedMatchData.homeCompetitorId) || "/placeholder.svg"}
                                alt={homeTeam?.name || ""}
                                width={48}
                                height={48}
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <p className="font-semibold">{homeTeam?.name}</p>
                              <p className="text-xs text-muted-foreground">Domaćin</p>
                            </div>
                          </div>
                          {selectedMatchData.result && (
                            <span className="text-xl font-bold">{selectedMatchData.result.homeScore}</span>
                          )}
                        </div>

                        <div className="flex items-center justify-center">
                          <span className="text-lg font-medium text-muted-foreground">vs</span>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-12 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                              <Image
                                src={getTeamLogo(selectedMatchData.awayCompetitorId) || "/placeholder.svg"}
                                alt={awayTeam?.name || ""}
                                width={48}
                                height={48}
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <p className="font-semibold">{awayTeam?.name}</p>
                              <p className="text-xs text-muted-foreground">Gost</p>
                            </div>
                          </div>
                          {selectedMatchData.result && (
                            <span className="text-xl font-bold">{selectedMatchData.result.awayScore}</span>
                          )}
                        </div>
                      </>
                    )
                  })()}
                </CardContent>
              </Card>

              <div className="flex gap-2 pt-4">
                <Button variant="outline" className="flex-1">
                  <Pencil className="h-4 w-4 mr-2" />
                  Uredi
                </Button>
                <Button variant="destructive" className="flex-1">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Izbriši
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </DashboardLayout>
  )
}
