"use client"

import { useState, useMemo } from "react"
import { notFound } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { getConfederationById, getCategoriesByConfederationId } from "@/lib/data"
import { PlusCircle, Pencil, Trash2, Users } from "lucide-react"
import { TableToolbar } from "@/components/table-toolbar"
import { CollapsibleTableRow } from "@/components/collapsible-table-row"
import { CategoryBadge } from "@/components/category-badge"

interface CategoriesPageProps {
  params: {
    id: string
  }
}

export default function CategoriesPage({ params }: CategoriesPageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const categories = getCategoriesByConfederationId(params.id)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCompact, setIsCompact] = useState(false)
  const [visibleColumns] = useState<string[]>(["name", "ageGroup", "gender"])

  const availableColumns = [
    { id: "name", title: "Naziv" },
    { id: "ageGroup", title: "Dobna skupina" },
    { id: "gender", title: "Spol" },
  ]

  const filteredCategories = useMemo(() => {
    return categories.filter(
      (category) =>
        searchTerm === "" ||
        category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        category.ageGroup.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (category.weightClass && category.weightClass.toLowerCase().includes(searchTerm.toLowerCase())),
    )
  }, [categories, searchTerm])

  const getGenderLabel = (gender: string) => {
    switch (gender) {
      case "M":
        return "Muški"
      case "F":
        return "Ženski"
      case "MIX":
        return "Mješovito"
      default:
        return gender
    }
  }

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-sky-100 flex items-center justify-center">
              <Users className="h-6 w-6 text-sky-700" />
            </div>
            <h1 className="text-3xl font-bold">Kategorije</h1>
          </div>
          <Button className="flex items-center gap-2 bg-sky-600 hover:bg-sky-700">
            <PlusCircle className="h-4 w-4" />
            <span>Dodaj kategoriju</span>
          </Button>
        </div>

        <TableToolbar
          searchPlaceholder="Pretraži kategorije..."
          onSearchChange={setSearchTerm}
          onCompactChange={setIsCompact}
          className="w-full"
        />

        <div className="rounded-md border bg-white">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-10"></TableHead>
                {visibleColumns.includes("name") && <TableHead className="pl-6">Naziv</TableHead>}
                {visibleColumns.includes("ageGroup") && <TableHead className="pl-6">Dobna skupina</TableHead>}
                {visibleColumns.includes("gender") && <TableHead className="pl-6">Spol</TableHead>}
                <TableHead className="text-right">Akcije</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCategories.length > 0 ? (
                filteredCategories.map((category) => (
                  <CollapsibleTableRow
                    key={category.id}
                    isCompact={isCompact}
                    expandedContent={
                      <div className="space-y-4 pl-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h3 className="text-sm font-medium mb-2">Detalji kategorije</h3>
                            <dl className="grid grid-cols-[150px_1fr] gap-2 text-sm">
                              <dt className="font-medium text-muted-foreground">ID:</dt>
                              <dd>{category.id}</dd>
                              <dt className="font-medium text-muted-foreground">Naziv:</dt>
                              <dd>{category.name}</dd>
                              <dt className="font-medium text-muted-foreground">Dobna skupina:</dt>
                              <dd>{category.ageGroup}</dd>
                              <dt className="font-medium text-muted-foreground">Spol:</dt>
                              <dd>
                                <CategoryBadge name={getGenderLabel(category.gender)} gender={category.gender} />
                              </dd>
                              {category.weightClass && (
                                <>
                                  <dt className="font-medium text-muted-foreground">Težinska kategorija:</dt>
                                  <dd>{category.weightClass}</dd>
                                </>
                              )}
                            </dl>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium mb-2">Statistika</h3>
                            <div className="flex items-center gap-2 text-sm">
                              <Users className="h-4 w-4 text-muted-foreground" />
                              <span>
                                Broj natjecatelja: <span className="font-medium">0</span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    }
                  >
                    {visibleColumns.includes("name") && (
                      <TableCell className="font-medium pl-6">{category.name}</TableCell>
                    )}

                    {visibleColumns.includes("ageGroup") && (
                      <TableCell className="pl-6">
                        <span className="px-2 py-1 bg-slate-100 rounded-md text-xs font-medium">
                          {category.ageGroup}
                        </span>
                      </TableCell>
                    )}

                    {visibleColumns.includes("gender") && (
                      <TableCell className="pl-6">
                        {category.gender && (
                          <CategoryBadge name={getGenderLabel(category.gender)} gender={category.gender} />
                        )}
                      </TableCell>
                    )}

                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={(e) => e.stopPropagation()}>
                          <Pencil className="h-4 w-4" />
                          <span className="sr-only">Uredi</span>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={(e) => e.stopPropagation()}>
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Izbriši</span>
                        </Button>
                      </div>
                    </TableCell>
                  </CollapsibleTableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    Nema kategorija za prikaz.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </DashboardLayout>
  )
}
