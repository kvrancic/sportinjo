"use client"

import { useState, useMemo } from "react"
import { notFound } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetClose } from "@/components/ui/sheet"
import {
  getConfederationById,
  getCategoriesByConfederationId,
  getCompetitorsByConfederationId,
  getCategoryById,
  getMatchesByConfederationId,
  getCompetitorById,
} from "@/lib/data"
import { PlusCircle, Pencil, Trash2, MapPin, User, Users, X } from "lucide-react"
import Image from "next/image"
import { getTeamLogo } from "@/lib/team-logos"
import { TableToolbar } from "@/components/table-toolbar"
import { CategoryBadge } from "@/components/category-badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatDate } from "@/lib/utils"
import { StatusBadge } from "@/components/status-badge"

interface CompetitorsPageProps {
  params: {
    id: string
  }
}

export default function CompetitorsPage({ params }: CompetitorsPageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const categories = getCategoriesByConfederationId(params.id)
  const competitors = getCompetitorsByConfederationId(params.id)
  const matches = getMatchesByConfederationId(params.id)

  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [isCompact, setIsCompact] = useState(false)
  const [selectedCompetitor, setSelectedCompetitor] = useState<string | null>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("info")

  const filteredCompetitors = useMemo(() => {
    return competitors.filter(
      (comp) =>
        (selectedCategoryId === "all" || comp.categoryIds.includes(selectedCategoryId)) &&
        (searchTerm === "" ||
          comp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (comp.city && comp.city.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (comp.coach && comp.coach.toLowerCase().includes(searchTerm.toLowerCase()))),
    )
  }, [competitors, selectedCategoryId, searchTerm])

  const handleCompetitorClick = (competitorId: string) => {
    setSelectedCompetitor(competitorId)
    setIsDetailOpen(true)
  }

  const selectedCompetitorData = useMemo(() => {
    if (!selectedCompetitor) return null
    return getCompetitorById(selectedCompetitor)
  }, [selectedCompetitor])

  // Get competitor matches
  const competitorMatches = useMemo(() => {
    if (!selectedCompetitor) return []
    return matches
      .filter((match) => match.homeCompetitorId === selectedCompetitor || match.awayCompetitorId === selectedCompetitor)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }, [selectedCompetitor, matches])

  // Calculate competitor stats
  const competitorStats = useMemo(() => {
    if (!selectedCompetitor) return null

    const completedMatches = competitorMatches.filter((match) => match.status === "COMPLETED")

    let wins = 0
    let draws = 0
    let losses = 0
    let goalsFor = 0
    let goalsAgainst = 0

    completedMatches.forEach((match) => {
      if (!match.result) return

      const isHome = match.homeCompetitorId === selectedCompetitor
      const homeScore = match.result.homeScore
      const awayScore = match.result.awayScore

      if (isHome) {
        goalsFor += homeScore
        goalsAgainst += awayScore

        if (homeScore > awayScore) wins++
        else if (homeScore === awayScore) draws++
        else losses++
      } else {
        goalsFor += awayScore
        goalsAgainst += homeScore

        if (awayScore > homeScore) wins++
        else if (awayScore === homeScore) draws++
        else losses++
      }
    })

    return {
      played: wins + draws + losses,
      wins,
      draws,
      losses,
      goalsFor,
      goalsAgainst,
      goalDifference: goalsFor - goalsAgainst,
      winPercentage: wins > 0 ? Math.round((wins / (wins + draws + losses)) * 100) : 0,
    }
  }, [selectedCompetitor, competitorMatches])

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-3xl font-bold">Natjecatelji</h1>
          </div>
          <Button className="flex items-center gap-2">
            <PlusCircle className="h-4 w-4" />
            <span>Dodaj natjecatelja</span>
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-full sm:w-72">
            <Select value={selectedCategoryId} onValueChange={setSelectedCategoryId}>
              <SelectTrigger className="bg-white">
                <SelectValue placeholder="Filtriraj po kategoriji" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Sve kategorije</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <TableToolbar
            searchPlaceholder="Pretraži natjecatelje..."
            onSearchChange={setSearchTerm}
            onCompactChange={setIsCompact}
            className="w-full"
          />
        </div>

        <div className="rounded-md border bg-white">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Naziv</TableHead>
                <TableHead>Tip</TableHead>
                <TableHead>Kategorije</TableHead>
                <TableHead className="text-right">Akcije</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCompetitors.length > 0 ? (
                filteredCompetitors.map((competitor) => (
                  <TableRow
                    key={competitor.id}
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => handleCompetitorClick(competitor.id)}
                  >
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                          <Image
                            src={getTeamLogo(competitor.id) || "/placeholder.svg"}
                            alt={competitor.name}
                            width={40}
                            height={40}
                            className="object-cover"
                          />
                        </div>
                        <span className="font-medium">{competitor.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span
                        className={`px-2 py-1 rounded-md text-xs font-medium ${
                          competitor.type === "TEAM" ? "bg-blue-100 text-blue-800" : "bg-purple-100 text-purple-800"
                        }`}
                      >
                        {competitor.type === "TEAM" ? "Ekipa" : "Pojedinac"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {competitor.categoryIds.slice(0, isCompact ? 1 : 3).map((catId) => {
                          const category = getCategoryById(catId)
                          return category ? (
                            <CategoryBadge key={catId} name={category.name} gender={category.gender} size="sm" />
                          ) : null
                        })}
                        {competitor.categoryIds.length > (isCompact ? 1 : 3) && (
                          <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold bg-gray-100">
                            +{competitor.categoryIds.length - (isCompact ? 1 : 3)}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation()
                            // Edit functionality would go here
                          }}
                        >
                          <Pencil className="h-4 w-4" />
                          <span className="sr-only">Uredi</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation()
                            // Delete functionality would go here
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Izbriši</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    Nema natjecatelja za prikaz.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Competitor Detail Sheet */}
      <Sheet open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <SheetContent className="sm:max-w-md overflow-y-auto">
          <SheetHeader className="pb-4">
            <div className="flex justify-between items-center">
              <SheetTitle>Detalji natjecatelja</SheetTitle>
              <SheetClose className="rounded-full h-8 w-8 flex items-center justify-center hover:bg-muted">
                <X className="h-4 w-4" />
              </SheetClose>
            </div>
            <SheetDescription>Pregledajte detalje odabranog natjecatelja</SheetDescription>
          </SheetHeader>

          {selectedCompetitorData && (
            <div className="space-y-6 mt-2">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-primary/20 shadow-md">
                  <Image
                    src={getTeamLogo(selectedCompetitorData.id) || "/placeholder.svg"}
                    alt={selectedCompetitorData.name}
                    width={64}
                    height={64}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-lg font-bold">{selectedCompetitorData.name}</h3>
                  <span
                    className={`px-2 py-0.5 rounded-md text-xs font-medium ${
                      selectedCompetitorData.type === "TEAM"
                        ? "bg-blue-100 text-blue-800"
                        : "bg-purple-100 text-purple-800"
                    }`}
                  >
                    {selectedCompetitorData.type === "TEAM" ? "Ekipa" : "Pojedinac"}
                  </span>
                </div>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="info">Informacije</TabsTrigger>
                  <TabsTrigger value="matches">Utakmice</TabsTrigger>
                  <TabsTrigger value="stats">Statistika</TabsTrigger>
                </TabsList>

                <TabsContent value="info" className="space-y-4 mt-4">
                  <Card className="border-2 border-muted">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Osnovne informacije</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {selectedCompetitorData.city && (
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-rose-500" />
                          <span className="font-medium">{selectedCompetitorData.city}</span>
                        </div>
                      )}
                      {selectedCompetitorData.coach && (
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-sky-500" />
                          <span className="font-medium">{selectedCompetitorData.coach}</span>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="border-2 border-muted">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Kategorije</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {selectedCompetitorData.categoryIds.map((catId) => {
                          const category = getCategoryById(catId)
                          return category ? (
                            <CategoryBadge
                              key={catId}
                              name={category.name}
                              gender={category.gender}
                              ageGroup={category.ageGroup}
                            />
                          ) : null
                        })}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="matches" className="space-y-4 mt-4">
                  <Card className="border-2 border-muted">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Nedavne utakmice</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {competitorMatches.length > 0 ? (
                        <div className="space-y-3">
                          {competitorMatches.slice(0, 5).map((match) => {
                            const isHome = match.homeCompetitorId === selectedCompetitorData.id
                            const opponentId = isHome ? match.awayCompetitorId : match.homeCompetitorId
                            const opponent = getCompetitorById(opponentId)
                            const category = getCategoryById(match.categoryId)

                            return (
                              <div key={match.id} className="border-b pb-3 last:border-0">
                                <div className="flex justify-between items-center">
                                  <div className="flex items-center gap-2">
                                    <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                                      <Image
                                        src={getTeamLogo(opponentId) || "/placeholder.svg"}
                                        alt={opponent?.name || ""}
                                        width={32}
                                        height={32}
                                        className="object-cover"
                                      />
                                    </div>
                                    <div>
                                      <p className="font-medium">
                                        {isHome ? "vs" : "@"} {opponent?.name}
                                      </p>
                                      <div className="flex items-center gap-1 mt-1">
                                        {category && (
                                          <CategoryBadge name={category.name} gender={category.gender} size="sm" />
                                        )}
                                        <StatusBadge status={match.status} size="sm" />
                                      </div>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-sm font-medium">{formatDate(match.date)}</p>
                                    {match.result && (
                                      <p className="text-base font-bold">
                                        {isHome ? match.result.homeScore : match.result.awayScore} -{" "}
                                        {isHome ? match.result.awayScore : match.result.homeScore}
                                      </p>
                                    )}
                                  </div>
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      ) : (
                        <div className="text-center py-4 text-muted-foreground">Nema utakmica za prikaz</div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="stats" className="space-y-4 mt-4">
                  {competitorStats ? (
                    <Card className="border-2 border-muted">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">Statistika</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Odigrano</span>
                              <span className="font-medium">{competitorStats.played}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Pobjede</span>
                              <span className="font-medium text-emerald-600">{competitorStats.wins}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Neriješeno</span>
                              <span className="font-medium text-amber-600">{competitorStats.draws}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Porazi</span>
                              <span className="font-medium text-rose-600">{competitorStats.losses}</span>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Golovi za</span>
                              <span className="font-medium">{competitorStats.goalsFor}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Golovi protiv</span>
                              <span className="font-medium">{competitorStats.goalsAgainst}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Gol razlika</span>
                              <span
                                className={`font-medium ${
                                  competitorStats.goalDifference > 0
                                    ? "text-emerald-600"
                                    : competitorStats.goalDifference < 0
                                      ? "text-rose-600"
                                      : ""
                                }`}
                              >
                                {competitorStats.goalDifference > 0
                                  ? `+${competitorStats.goalDifference}`
                                  : competitorStats.goalDifference}
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Postotak pobjeda</span>
                              <span className="font-medium">{competitorStats.winPercentage}%</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="text-center py-4 text-muted-foreground">Nema statistike za prikaz</div>
                  )}
                </TabsContent>
              </Tabs>

              <div className="flex gap-2 pt-4">
                <Button variant="outline" className="flex-1">
                  <Pencil className="h-4 w-4 mr-2" />
                  Uredi
                </Button>
                <Button variant="destructive" className="flex-1">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Izbriši
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </DashboardLayout>
  )
}
