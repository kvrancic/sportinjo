import { notFound } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { SummaryCard } from "@/components/summary-card"
import { QuickLinkCard } from "@/components/quick-link-card"
import { BarChart3, Calendar, ListChecks, Medal, Trophy, Users } from "lucide-react"
import {
  getConfederationById,
  getCategoriesByConfederationId,
  getCompetitorsByConfederationId,
  getUpcomingMatches,
  getRecentResults,
  getCompetitorById,
  getCategoryById,
} from "@/lib/data"
import { formatDate } from "@/lib/utils"
import { getSportIcon } from "@/lib/sport-icons"
import { getTeamLogo } from "@/lib/team-logos"
import Image from "next/image"
import { StatusBadge } from "@/components/status-badge"
import { CategoryBadge } from "@/components/category-badge"

interface HomePageProps {
  params: {
    id: string
  }
}

export default function HomePage({ params }: HomePageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const SportIcon = getSportIcon(confederation.sport)
  const categories = getCategoriesByConfederationId(params.id)
  const competitors = getCompetitorsByConfederationId(params.id)
  const upcomingMatches = getUpcomingMatches(params.id, 3)
  const recentResults = getRecentResults(params.id, 3)

  // Calculate some trends for the summary cards
  const totalMatches = upcomingMatches.length + recentResults.length
  const completedMatches = recentResults.filter((match) => match.status === "COMPLETED").length
  const completionRate = totalMatches > 0 ? Math.round((completedMatches / totalMatches) * 100) : 0

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
            <SportIcon className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Početna stranica</h1>
            <p className="text-muted-foreground">{confederation.sport} - Admin portal</p>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <SummaryCard
            title="Broj kategorija"
            value={categories.length}
            icon={ListChecks}
            description="Ukupan broj kategorija u savezu"
            variant="info"
          />
          <SummaryCard
            title="Broj natjecatelja"
            value={competitors.length}
            icon={Users}
            description="Ukupan broj klubova/pojedinaca"
            variant="primary"
          />
          <SummaryCard
            title="Nadolazeći mečevi"
            value={upcomingMatches.length}
            icon={Calendar}
            description="Zakazani mečevi u sljedećih 7 dana"
            variant="warning"
            trend="up"
            trendValue={`+${upcomingMatches.length > 0 ? upcomingMatches.length : 0}`}
          />
          <SummaryCard
            title="Zadnji rezultati"
            value={recentResults.length}
            icon={Medal}
            description={`Stopa završenosti: ${completionRate}%`}
            variant="success"
            trend="neutral"
            trendValue={`${completedMatches}/${totalMatches}`}
          />
        </div>

        {/* Quick Links */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Brzi linkovi</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <QuickLinkCard
              title="Kategorije"
              href={`/confederations/${params.id}/categories`}
              icon={ListChecks}
              variant="info"
            />
            <QuickLinkCard
              title="Natjecatelji"
              href={`/confederations/${params.id}/competitors`}
              icon={Users}
              variant="primary"
            />
            <QuickLinkCard
              title="Kalendar"
              href={`/confederations/${params.id}/calendar`}
              icon={Calendar}
              variant="warning"
            />
            <QuickLinkCard
              title="Rezultati"
              href={`/confederations/${params.id}/results`}
              icon={Medal}
              variant="success"
            />
            <QuickLinkCard
              title="Poredak"
              href={`/confederations/${params.id}/standings`}
              icon={Trophy}
              variant="danger"
            />
            <QuickLinkCard
              title="Statistika"
              href={`/confederations/${params.id}/statistics`}
              icon={BarChart3}
              variant="info"
            />
          </div>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upcoming Matches */}
          <div className="bg-white rounded-lg border shadow-sm p-4">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Calendar className="h-5 w-5 text-amber-500" />
              <span>Nadolazeći mečevi</span>
            </h2>
            {upcomingMatches.length > 0 ? (
              <div className="space-y-4">
                {upcomingMatches.map((match) => {
                  const homeTeam = getCompetitorById(match.homeCompetitorId)
                  const awayTeam = getCompetitorById(match.awayCompetitorId)
                  const category = getCategoryById(match.categoryId)

                  return (
                    <div key={match.id} className="border-b pb-3 last:border-0">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            <div className="h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                              <Image
                                src={getTeamLogo(match.homeCompetitorId) || "/placeholder.svg"}
                                alt={homeTeam?.name || ""}
                                width={40}
                                height={40}
                                className="object-cover"
                              />
                            </div>
                            <span className="font-semibold text-lg">vs</span>
                            <div className="h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                              <Image
                                src={getTeamLogo(match.awayCompetitorId) || "/placeholder.svg"}
                                alt={awayTeam?.name || ""}
                                width={40}
                                height={40}
                                className="object-cover"
                              />
                            </div>
                          </div>
                          <div>
                            <p className="font-medium">
                              {homeTeam?.name} vs {awayTeam?.name}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              {category && <CategoryBadge name={category.name} gender={category.gender} size="sm" />}
                              <StatusBadge status={match.status} size="sm" />
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">{formatDate(match.date)}</p>
                          <p className="text-xs text-muted-foreground">{match.venue}</p>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <div className="text-muted-foreground bg-muted/30 rounded-lg p-4 text-center">
                Nema nadolazećih mečeva
              </div>
            )}
          </div>

          {/* Recent Results */}
          <div className="bg-white rounded-lg border shadow-sm p-4">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Medal className="h-5 w-5 text-emerald-500" />
              <span>Zadnji rezultati</span>
            </h2>
            {recentResults.length > 0 ? (
              <div className="space-y-4">
                {recentResults.map((match) => {
                  const homeTeam = getCompetitorById(match.homeCompetitorId)
                  const awayTeam = getCompetitorById(match.awayCompetitorId)
                  const category = getCategoryById(match.categoryId)
                  const homeWon = match.result && match.result.homeScore > match.result.awayScore
                  const awayWon = match.result && match.result.homeScore < match.result.awayScore
                  const draw = match.result && match.result.homeScore === match.result.awayScore

                  return (
                    <div key={match.id} className="border-b pb-3 last:border-0">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2">
                            <div
                              className={`h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 ${homeWon ? "border-emerald-300" : draw ? "border-amber-300" : "border-white"} shadow-sm`}
                            >
                              <Image
                                src={getTeamLogo(match.homeCompetitorId) || "/placeholder.svg"}
                                alt={homeTeam?.name || ""}
                                width={40}
                                height={40}
                                className="object-cover"
                              />
                            </div>
                            <div className="flex flex-col items-center">
                              <span className="font-bold text-lg">
                                {match.result?.homeScore} - {match.result?.awayScore}
                              </span>
                              <StatusBadge status={match.status} size="sm" />
                            </div>
                            <div
                              className={`h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 ${awayWon ? "border-emerald-300" : draw ? "border-amber-300" : "border-white"} shadow-sm`}
                            >
                              <Image
                                src={getTeamLogo(match.awayCompetitorId) || "/placeholder.svg"}
                                alt={awayTeam?.name || ""}
                                width={40}
                                height={40}
                                className="object-cover"
                              />
                            </div>
                          </div>
                          <div>
                            <p className="font-medium">
                              {homeTeam?.name} vs {awayTeam?.name}
                            </p>
                            {category && (
                              <div className="mt-1">
                                <CategoryBadge name={category.name} gender={category.gender} size="sm" />
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">{formatDate(match.date)}</p>
                          <p className="text-xs text-muted-foreground">{match.venue}</p>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <div className="text-muted-foreground bg-muted/30 rounded-lg p-4 text-center">
                Nema nedavnih rezultata
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
