"use client"

import { useState, useMemo } from "react"
import { Input } from "@/components/ui/input"
import { notFound } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getConfederationById, getMatchesByConfederationId, getCompetitorById, getCategoryById } from "@/lib/data"
import { formatDate } from "@/lib/utils"
import { CheckCircle2, CalendarIcon, MapPin, Medal } from "lucide-react"
import { getTeamLogo } from "@/lib/team-logos"
import Image from "next/image"
import { TableToolbar } from "@/components/table-toolbar"
import { CollapsibleTableRow } from "@/components/collapsible-table-row"
import { CategoryBadge } from "@/components/category-badge"
import { StatusBadge } from "@/components/status-badge"

interface ResultsPageProps {
  params: {
    id: string
  }
}

export default function ResultsPage({ params }: ResultsPageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const allMatches = getMatchesByConfederationId(params.id)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCompact, setIsCompact] = useState(false)
  const [visibleColumns] = useState<string[]>(["date", "category", "teams", "result", "status"])

  const availableColumns = [
    { id: "date", title: "Datum i vrijeme" },
    { id: "category", title: "Kategorija" },
    { id: "teams", title: "Timovi" },
    { id: "result", title: "Rezultat" },
    { id: "status", title: "Status" },
  ]

  const formatDateTimeInline = (dateString: string): string => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("hr-HR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const filteredMatches = useMemo(() => {
    return allMatches
      .filter((match) => match.status === "SCHEDULED" || match.status === "IN_PROGRESS")
      .filter((match) => {
        if (searchTerm === "") return true

        const homeTeam = getCompetitorById(match.homeCompetitorId)
        const awayTeam = getCompetitorById(match.awayCompetitorId)
        const category = getCategoryById(match.categoryId)

        return (
          (homeTeam && homeTeam.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (awayTeam && awayTeam.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (category && category.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          match.venue.toLowerCase().includes(searchTerm.toLowerCase()) ||
          formatDate(match.date).toLowerCase().includes(searchTerm.toLowerCase())
        )
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  }, [allMatches, searchTerm])

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center">
              <Medal className="h-6 w-6 text-emerald-700" />
            </div>
            <h1 className="text-3xl font-bold">Unos rezultata</h1>
          </div>
        </div>

        <TableToolbar
          searchPlaceholder="Pretraži mečeve..."
          onSearchChange={setSearchTerm}
          onCompactChange={setIsCompact}
          className="w-full"
        />

        <div className="rounded-md border bg-white">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Datum i vrijeme</TableHead>
                <TableHead>Kategorija</TableHead>
                <TableHead>Timovi</TableHead>
                <TableHead>Rezultat</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Akcije</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMatches.length > 0 ? (
                filteredMatches.map((match) => {
                  const homeTeam = getCompetitorById(match.homeCompetitorId)
                  const awayTeam = getCompetitorById(match.awayCompetitorId)
                  const category = getCategoryById(match.categoryId)

                  return (
                    <CollapsibleTableRow
                      key={match.id}
                      isCompact={isCompact}
                      expandedContent={
                        <div className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h3 className="text-sm font-medium mb-2">Detalji meča</h3>
                              <dl className="grid grid-cols-[120px_1fr] gap-2 text-sm">
                                <dt className="font-medium text-muted-foreground">ID:</dt>
                                <dd>{match.id}</dd>
                                <dt className="font-medium text-muted-foreground">Datum:</dt>
                                <dd className="flex items-center gap-1">
                                  <CalendarIcon className="h-3.5 w-3.5 text-amber-500" />
                                  {formatDate(match.date)}
                                </dd>
                                <dt className="font-medium text-muted-foreground">Lokacija:</dt>
                                <dd className="flex items-center gap-1">
                                  <MapPin className="h-3.5 w-3.5 text-rose-500" />
                                  {match.venue}
                                </dd>
                                <dt className="font-medium text-muted-foreground">Kategorija:</dt>
                                <dd>{category && <CategoryBadge name={category.name} gender={category.gender} />}</dd>
                              </dl>
                            </div>
                            <div>
                              <h3 className="text-sm font-medium mb-2">Unos rezultata</h3>
                              <div className="flex flex-col gap-4 p-4 border rounded-lg bg-muted/20">
                                <div className="flex items-center gap-3">
                                  <div className="flex items-center gap-2">
                                    <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                                      <Image
                                        src={getTeamLogo(match.homeCompetitorId) || "/placeholder.svg"}
                                        alt={homeTeam?.name || ""}
                                        width={32}
                                        height={32}
                                        className="object-cover"
                                      />
                                    </div>
                                    <span className="font-medium">{homeTeam?.name}</span>
                                  </div>
                                  <Input type="number" min="0" className="w-16 text-center" placeholder="0" />
                                </div>
                                <div className="flex items-center gap-3">
                                  <div className="flex items-center gap-2">
                                    <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                                      <Image
                                        src={getTeamLogo(match.awayCompetitorId) || "/placeholder.svg"}
                                        alt={awayTeam?.name || ""}
                                        width={32}
                                        height={32}
                                        className="object-cover"
                                      />
                                    </div>
                                    <span className="font-medium">{awayTeam?.name}</span>
                                  </div>
                                  <Input type="number" min="0" className="w-16 text-center" placeholder="0" />
                                </div>
                                <div className="mt-2">
                                  <Select defaultValue={match.status}>
                                    <SelectTrigger className="w-full">
                                      <SelectValue placeholder="Status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="SCHEDULED">Zakazano</SelectItem>
                                      <SelectItem value="IN_PROGRESS">U tijeku</SelectItem>
                                      <SelectItem value="COMPLETED">Završeno</SelectItem>
                                      <SelectItem value="CANCELLED">Otkazano</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="mt-2 flex justify-end">
                                  <Button className="w-full flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700">
                                    <CheckCircle2 className="h-4 w-4" />
                                    <span>Spremi rezultat</span>
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      }
                    >
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{formatDateTimeInline(match.date)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {category && <CategoryBadge name={category.name} gender={category.gender} size="sm" />}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                            <Image
                              src={getTeamLogo(match.homeCompetitorId) || "/placeholder.svg"}
                              alt={homeTeam?.name || ""}
                              width={32}
                              height={32}
                              className="object-cover"
                            />
                          </div>
                          <span className="font-medium text-lg">vs</span>
                          <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                            <Image
                              src={getTeamLogo(match.awayCompetitorId) || "/placeholder.svg"}
                              alt={awayTeam?.name || ""}
                              width={32}
                              height={32}
                              className="object-cover"
                            />
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {match.result ? (
                          <span className="font-medium">
                            {match.result.homeScore} - {match.result.awayScore}
                          </span>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Input type="number" min="0" className="w-16 text-center" placeholder="0" />
                            <span>-</span>
                            <Input type="number" min="0" className="w-16 text-center" placeholder="0" />
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={match.status} size="sm" />
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          className="ml-auto flex items-center gap-1 bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-800"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <CheckCircle2 className="h-4 w-4" />
                          <span>Spremi</span>
                        </Button>
                      </TableCell>
                    </CollapsibleTableRow>
                  )
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    <div className="flex flex-col items-center justify-center text-muted-foreground">
                      <Medal className="h-8 w-8 mb-2 text-muted" />
                      <p>Nema mečeva za unos rezultata.</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </DashboardLayout>
  )
}
