"use client"

import { useState, useMemo } from "react"
import { notFound } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  getConfederationById,
  getCategoriesByConfederationId,
  getCompetitorsByConfederationId,
  getMatchesByConfederationId,
  getCompetitorById,
} from "@/lib/data"
import { getTeamLogo } from "@/lib/team-logos"
import Image from "next/image"
import { TableToolbar } from "@/components/table-toolbar"
import { CollapsibleTableRow } from "@/components/collapsible-table-row"
import { Trophy } from "lucide-react"
import { CategoryBadge } from "@/components/category-badge"

interface StandingsPageProps {
  params: {
    id: string
  }
}

// Add this type definition after the StandingsPageProps interface
type StandingItem = {
  id: string
  name: string
  played: number
  wins: number
  draws: number
  losses: number
  goalsFor: number
  goalsAgainst: number
  goalDifference: number
  points: number
  matches: Match[]
}

// Helper function to calculate standings with proper type definitions
function calculateStandings(
  matches: Match[],
  competitors: Competitor[],
  categoryId: string | null,
): Array<{
  id: string
  name: string
  played: number
  wins: number
  draws: number
  losses: number
  goalsFor: number
  goalsAgainst: number
  goalDifference: number
  points: number
  matches: Match[]
}> {
  const standings = competitors
    .filter((comp) => !categoryId || comp.categoryIds.includes(categoryId))
    .map((competitor) => {
      const relevantMatches = matches.filter(
        (match) =>
          match.status === "COMPLETED" &&
          (!categoryId || match.categoryId === categoryId) &&
          (match.homeCompetitorId === competitor.id || match.awayCompetitorId === competitor.id),
      )

      let wins = 0
      let draws = 0
      let losses = 0
      let goalsFor = 0
      let goalsAgainst = 0
      let points = 0

      relevantMatches.forEach((match) => {
        if (!match.result) return

        const isHome = match.homeCompetitorId === competitor.id
        const homeScore = match.result.homeScore
        const awayScore = match.result.awayScore

        if (isHome) {
          goalsFor += homeScore
          goalsAgainst += awayScore

          if (homeScore > awayScore) {
            wins++
            points += 3
          } else if (homeScore === awayScore) {
            draws++
            points += 1
          } else {
            losses++
          }
        } else {
          goalsFor += awayScore
          goalsAgainst += homeScore

          if (awayScore > homeScore) {
            wins++
            points += 3
          } else if (awayScore === homeScore) {
            draws++
            points += 1
          } else {
            losses++
          }
        }
      })

      return {
        id: competitor.id,
        name: competitor.name,
        played: wins + draws + losses,
        wins,
        draws,
        losses,
        goalsFor,
        goalsAgainst,
        goalDifference: goalsFor - goalsAgainst,
        points,
        matches: relevantMatches,
      }
    })
    .sort((a, b) => {
      // Sort by points (descending)
      if (a.points !== b.points) return b.points - a.points
      // If points are equal, sort by goal difference
      if (a.goalDifference !== b.goalDifference) return b.goalDifference - a.goalDifference
      // If goal difference is equal, sort by goals scored
      return b.goalsFor - a.goalsFor
    })

  return standings
}

export interface Match {
  id: string
  homeCompetitorId: string
  awayCompetitorId: string
  categoryId: string
  status: string
  result: {
    homeScore: number
    awayScore: number
  } | null
}

export interface Competitor {
  id: string
  name: string
  categoryIds: string[]
}

export default function StandingsPage({ params }: StandingsPageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const categories = getCategoriesByConfederationId(params.id)
  const competitors = getCompetitorsByConfederationId(params.id)
  const matches = getMatchesByConfederationId(params.id)

  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [isCompact, setIsCompact] = useState(false)
  const [visibleColumns] = useState<string[]>(["position", "team", "played", "record", "points"])

  const availableColumns = [
    { id: "position", title: "Pozicija" },
    { id: "team", title: "Klub" },
    { id: "played", title: "Odigrano" },
    { id: "points", title: "Bodovi" },
    { id: "record", title: "P-N-I" },
    { id: "goals", title: "Golovi" },
  ]

  const handleColumnVisibilityChange = (columnId: string, isVisible: boolean) => {
    if (isVisible) {
      // setVisibleColumns((prev) => [...prev, columnId])
    } else {
      // setVisibleColumns((prev) => prev.filter((id) => id !== columnId))
    }
  }

  // Then update the useMemo hook to use this type
  const standings = useMemo<StandingItem[]>(() => {
    return calculateStandings(matches, competitors, selectedCategoryId === "all" ? null : selectedCategoryId).filter(
      (team) => searchTerm === "" || team.name.toLowerCase().includes(searchTerm.toLowerCase()),
    )
  }, [matches, competitors, selectedCategoryId, searchTerm])

  // Get the selected category for display
  const selectedCategory = selectedCategoryId !== "all" ? categories.find((cat) => cat.id === selectedCategoryId) : null

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-rose-100 flex items-center justify-center">
              <Trophy className="h-6 w-6 text-rose-700" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Poredak</h1>
              {selectedCategory && (
                <div className="mt-1">
                  <CategoryBadge name={selectedCategory.name} gender={selectedCategory.gender} />
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-full sm:w-72">
            <Select value={selectedCategoryId} onValueChange={setSelectedCategoryId}>
              <SelectTrigger className="bg-white">
                <SelectValue placeholder="Sve kategorije" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Sve kategorije</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <TableToolbar
            searchPlaceholder="Pretraži klubove..."
            onSearchChange={setSearchTerm}
            onCompactChange={setIsCompact}
            className="w-full"
          />
        </div>

        <div className="rounded-md border bg-white">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-20 text-center">Pozicija</TableHead>
                <TableHead>Klub</TableHead>
                <TableHead className="w-24 text-center">Odigrano</TableHead>
                <TableHead className="w-16 text-center">P</TableHead>
                <TableHead className="w-16 text-center">N</TableHead>
                <TableHead className="w-16 text-center">I</TableHead>
                <TableHead className="w-24 text-center">Bodovi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {standings.length > 0 ? (
                standings.map((team, index) => (
                  <CollapsibleTableRow
                    key={team.id}
                    isCompact={isCompact}
                    className={
                      index === 0
                        ? "bg-amber-50 border-l-4 border-amber-400"
                        : index === 1
                          ? "bg-slate-50 border-l-4 border-slate-400"
                          : index === 2
                            ? "bg-orange-50 border-l-4 border-orange-400"
                            : ""
                    }
                    expandedContent={
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h3 className="text-sm font-medium mb-2">Detalji kluba</h3>
                            <dl className="grid grid-cols-[120px_1fr] gap-2 text-sm">
                              <dt className="font-medium text-muted-foreground">ID:</dt>
                              <dd>{team.id}</dd>
                              <dt className="font-medium text-muted-foreground">Naziv:</dt>
                              <dd>{team.name}</dd>
                              <dt className="font-medium text-muted-foreground">Pozicija:</dt>
                              <dd>
                                <span
                                  className={`px-2 py-1 rounded-md text-xs font-medium ${
                                    index === 0
                                      ? "bg-amber-100 text-amber-800"
                                      : index === 1
                                        ? "bg-slate-100 text-slate-800"
                                        : index === 2
                                          ? "bg-orange-100 text-orange-800"
                                          : "bg-gray-100 text-gray-800"
                                  }`}
                                >
                                  {index + 1}.
                                </span>
                              </dd>
                            </dl>
                          </div>
                          <div>
                            <h3 className="text-sm font-medium mb-2">Statistika</h3>
                            <dl className="grid grid-cols-[120px_1fr] gap-2 text-sm">
                              <dt className="font-medium text-muted-foreground">Odigrano:</dt>
                              <dd>{team.played}</dd>
                              <dt className="font-medium text-muted-foreground">Pobjede:</dt>
                              <dd className="text-emerald-600 font-medium">{team.wins}</dd>
                              <dt className="font-medium text-muted-foreground">Neriješeno:</dt>
                              <dd className="text-amber-600 font-medium">{team.draws}</dd>
                              <dt className="font-medium text-muted-foreground">Izgubljeno:</dt>
                              <dd className="text-rose-600 font-medium">{team.losses}</dd>
                              <dt className="font-medium text-muted-foreground">Golovi dani:</dt>
                              <dd>{team.goalsFor}</dd>
                              <dt className="font-medium text-muted-foreground">Golovi primljeni:</dt>
                              <dd>{team.goalsAgainst}</dd>
                              <dt className="font-medium text-muted-foreground">Gol razlika:</dt>
                              <dd
                                className={
                                  team.goalDifference > 0
                                    ? "text-emerald-600 font-medium"
                                    : team.goalDifference < 0
                                      ? "text-rose-600 font-medium"
                                      : ""
                                }
                              >
                                {team.goalDifference > 0 ? `+${team.goalDifference}` : team.goalDifference}
                              </dd>
                              <dt className="font-medium text-muted-foreground">Bodovi:</dt>
                              <dd className="font-bold text-lg">{team.points}</dd>
                            </dl>
                          </div>
                        </div>

                        {team.matches.length > 0 && (
                          <div>
                            <h3 className="text-sm font-medium mb-2">Zadnji mečevi</h3>
                            <div className="grid grid-cols-1 gap-2">
                              {team.matches.slice(0, 5).map((match) => {
                                const isHome = match.homeCompetitorId === team.id
                                const opponentId = isHome ? match.awayCompetitorId : match.homeCompetitorId
                                const opponent = getCompetitorById(opponentId)
                                const result = match.result
                                const teamScore = isHome ? result?.homeScore : result?.awayScore
                                const opponentScore = isHome ? result?.awayScore : result?.homeScore
                                const isWin = teamScore > opponentScore
                                const isDraw = teamScore === opponentScore

                                return (
                                  <div key={match.id} className="flex items-center gap-2 text-sm">
                                    <div
                                      className={`w-6 h-6 flex items-center justify-center rounded-full ${
                                        isWin
                                          ? "bg-emerald-100 text-emerald-800"
                                          : isDraw
                                            ? "bg-amber-100 text-amber-800"
                                            : "bg-rose-100 text-rose-800"
                                      }`}
                                    >
                                      {isWin ? "P" : isDraw ? "N" : "I"}
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span>{isHome ? "vs" : "@"}</span>
                                      <div className="h-6 w-6 rounded-full overflow-hidden bg-muted flex items-center justify-center border border-white shadow-sm">
                                        <Image
                                          src={getTeamLogo(opponentId) || "/placeholder.svg"}
                                          alt={opponent?.name || ""}
                                          width={24}
                                          height={24}
                                          className="object-cover"
                                        />
                                      </div>
                                      <span>{opponent?.name}</span>
                                      <span
                                        className={`font-medium ${
                                          isWin ? "text-emerald-600" : isDraw ? "text-amber-600" : "text-rose-600"
                                        }`}
                                      >
                                        {teamScore}-{opponentScore}
                                      </span>
                                    </div>
                                  </div>
                                )
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    }
                  >
                    <TableCell className="text-center">
                      <div
                        className={`mx-auto flex items-center justify-center w-6 h-6 rounded-full font-medium ${
                          index === 0
                            ? "bg-amber-100 text-amber-800"
                            : index === 1
                              ? "bg-slate-100 text-slate-800"
                              : index === 2
                                ? "bg-orange-100 text-orange-800"
                                : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {index + 1}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                          <Image
                            src={getTeamLogo(team.id) || "/placeholder.svg"}
                            alt={team.name}
                            width={32}
                            height={32}
                            className="object-cover"
                          />
                        </div>
                        <span className="font-medium">{team.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center font-medium">{team.played}</TableCell>
                    <TableCell className="text-center text-emerald-600 font-medium">{team.wins}</TableCell>
                    <TableCell className="text-center text-amber-600 font-medium">{team.draws}</TableCell>
                    <TableCell className="text-center text-rose-600 font-medium">{team.losses}</TableCell>
                    <TableCell className="text-center">
                      <span className="inline-flex items-center justify-center px-3 py-1 rounded-md font-bold text-white bg-primary">
                        {team.points}
                      </span>
                    </TableCell>
                  </CollapsibleTableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    <div className="flex flex-col items-center justify-center text-muted-foreground">
                      <Trophy className="h-8 w-8 mb-2 text-muted" />
                      <p>Nema podataka za prikaz.</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </DashboardLayout>
  )
}
