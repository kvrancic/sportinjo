"use client"

import { notFound } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  getConfederationById,
  getCategoriesByConfederationId,
  getCompetitorsByConfederationId,
  getMatchesByConfederationId,
} from "@/lib/data"
import { useState } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface StatisticsPageProps {
  params: {
    id: string
  }
}

// Helper function to calculate top scorers (simplified for demo)
function calculateTopScorers(matches, competitors, categoryId) {
  // In a real app, this would use actual player data
  // For this demo, we'll use teams as "scorers" based on goals
  const scorers = competitors
    .filter((comp) => !categoryId || comp.categoryIds.includes(categoryId))
    .map((competitor) => {
      const relevantMatches = matches.filter(
        (match) =>
          match.status === "COMPLETED" &&
          (!categoryId || match.categoryId === categoryId) &&
          (match.homeCompetitorId === competitor.id || match.awayCompetitorId === competitor.id),
      )

      let goals = 0

      relevantMatches.forEach((match) => {
        if (!match.result) return

        const isHome = match.homeCompetitorId === competitor.id

        if (isHome) {
          goals += match.result.homeScore
        } else {
          goals += match.result.awayScore
        }
      })

      return {
        id: competitor.id,
        name: competitor.name,
        goals,
      }
    })
    .sort((a, b) => b.goals - a.goals)
    .slice(0, 5)

  return scorers
}

// Helper function to calculate match statistics
function calculateMatchStatistics(matches, categoryId) {
  const completedMatches = matches.filter(
    (match) => match.status === "COMPLETED" && (!categoryId || match.categoryId === categoryId),
  )

  const totalMatches = completedMatches.length
  const totalGoals = completedMatches.reduce((sum, match) => {
    if (!match.result) return sum
    return sum + match.result.homeScore + match.result.awayScore
  }, 0)

  const homeWins = completedMatches.filter(
    (match) => match.result && match.result.homeScore > match.result.awayScore,
  ).length

  const awayWins = completedMatches.filter(
    (match) => match.result && match.result.homeScore < match.result.awayScore,
  ).length

  const draws = completedMatches.filter(
    (match) => match.result && match.result.homeScore === match.result.awayScore,
  ).length

  return {
    totalMatches,
    totalGoals,
    goalsPerMatch: totalMatches > 0 ? (totalGoals / totalMatches).toFixed(2) : 0,
    homeWins,
    awayWins,
    draws,
  }
}

export default function StatisticsPage({ params }: StatisticsPageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const categories = getCategoriesByConfederationId(params.id)
  const competitors = getCompetitorsByConfederationId(params.id)
  const matches = getMatchesByConfederationId(params.id)

  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("")

  const topScorers = calculateTopScorers(matches, competitors, selectedCategoryId)
  const matchStats = calculateMatchStatistics(matches, selectedCategoryId)

  const chartData = [
    { name: "Pobjede domaćina", value: matchStats.homeWins },
    { name: "Pobjede gosta", value: matchStats.awayWins },
    { name: "Neriješeno", value: matchStats.draws },
  ]

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Statistika</h1>

          <div className="w-72">
            <Select value={selectedCategoryId} onValueChange={setSelectedCategoryId}>
              <SelectTrigger>
                <SelectValue placeholder="Sve kategorije" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Sve kategorije</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Ukupno utakmica</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{matchStats.totalMatches}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Ukupno golova</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{matchStats.totalGoals}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Prosjek golova po utakmici</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{matchStats.goalsPerMatch}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Match Results Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Rezultati utakmica</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Top Scorers */}
          <Card>
            <CardHeader>
              <CardTitle>Najbolji strijelci</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pozicija</TableHead>
                    <TableHead>Klub</TableHead>
                    <TableHead className="text-right">Golovi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topScorers.length > 0 ? (
                    topScorers.map((scorer, index) => (
                      <TableRow key={scorer.id}>
                        <TableCell className="font-medium">{index + 1}</TableCell>
                        <TableCell>{scorer.name}</TableCell>
                        <TableCell className="text-right">{scorer.goals}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={3} className="h-24 text-center">
                        Nema podataka za prikaz.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
