"use client"

import { useState, useEffect } from "react"
import { notFound, useRouter } from "next/navigation"
import { getConfederationById, getCategoriesByConfederationId, getCompetitorsByConfederationId } from "@/lib/data"
import { WizardLayout } from "@/components/tournament/wizard-layout"
import { Step1NameFormat } from "@/components/tournament/step-1-name-format"
import { Step2Categories } from "@/components/tournament/step-2-categories"
import { Step3Teams } from "@/components/tournament/step-3-teams"
import { Step4TimeLocation } from "@/components/tournament/step-4-time-location"
import { Step5Schedule } from "@/components/tournament/step-5-schedule"
import { Step6Review } from "@/components/tournament/step-6-review"
import {
  type TournamentFormat,
  type TournamentMatch,
  generateTournamentMatches,
  venueOptions,
} from "@/lib/tournament-data"
import { v4 as uuidv4 } from "uuid"

interface NoviTurnirPageProps {
  params: {
    id: string
  }
}

export default function NoviTurnirPage({ params }: NoviTurnirPageProps) {
  const router = useRouter()
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const categories = getCategoriesByConfederationId(params.id)
  const competitors = getCompetitorsByConfederationId(params.id)

  // Wizard state
  const [currentStep, setCurrentStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState<number[]>([])

  // Tournament data
  const [name, setName] = useState("")
  const [format, setFormat] = useState<TournamentFormat>("ROUND_ROBIN")
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([])
  const [selectedCompetitorIds, setSelectedCompetitorIds] = useState<string[]>([])
  const [startDate, setStartDate] = useState<Date>(new Date())
  const [endDate, setEndDate] = useState<Date>(() => {
    const date = new Date()
    date.setDate(date.getDate() + 30) // Default to 30 days later
    return date
  })
  const [venue, setVenue] = useState<string>(venueOptions[0]?.id || "")
  const [matches, setMatches] = useState<TournamentMatch[]>([])

  // Generate matches when competitors are selected
  useEffect(() => {
    if (selectedCompetitorIds.length > 0) {
      const tournamentData = {
        id: uuidv4(),
        name,
        format,
        categoryIds: selectedCategoryIds,
        competitorIds: selectedCompetitorIds,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        venue,
        matches: [],
        status: "DRAFT",
        confederationId: params.id,
        createdAt: new Date().toISOString(),
      }

      const generatedMatches = generateTournamentMatches(tournamentData)
      setMatches(generatedMatches)
    }
  }, [selectedCompetitorIds, format, name, selectedCategoryIds, startDate, endDate, venue, params.id])

  // Step validation
  const isStep1Valid = name.length >= 3 && format
  const isStep2Valid = selectedCategoryIds.length > 0
  const isStep3Valid = selectedCompetitorIds.length >= (format === "ROUND_ROBIN" ? 3 : 4)
  const isStep4Valid = startDate && endDate && startDate < endDate && venue
  const isStep5Valid = matches.length > 0

  const isNextDisabled =
    (currentStep === 0 && !isStep1Valid) ||
    (currentStep === 1 && !isStep2Valid) ||
    (currentStep === 2 && !isStep3Valid) ||
    (currentStep === 3 && !isStep4Valid) ||
    (currentStep === 4 && !isStep5Valid)

  // Wizard steps
  const steps = [
    { id: "step-1", title: "Naziv i format" },
    { id: "step-2", title: "Kategorije" },
    { id: "step-3", title: "Ekipe" },
    { id: "step-4", title: "Vrijeme i lokacija" },
    { id: "step-5", title: "Raspored" },
    { id: "step-6", title: "Pregled" },
  ]

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      // Mark current step as completed
      if (!completedSteps.includes(currentStep)) {
        setCompletedSteps([...completedSteps, currentStep])
      }

      // Move to next step
      setCurrentStep(currentStep + 1)
      // Scroll to top when changing steps
      window.scrollTo(0, 0)
    } else {
      // Final step - save tournament
      handleSaveTournament(false)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
      // Scroll to top when changing steps
      window.scrollTo(0, 0)
    }
  }

  const handleEditStep = (step: number) => {
    setCurrentStep(step)
    // Scroll to top when changing steps
    window.scrollTo(0, 0)
  }

  const handleSaveTournament = (isDraft: boolean) => {
    // In a real app, this would save to a database
    console.log("Saving tournament:", {
      id: uuidv4(),
      name,
      format,
      categoryIds: selectedCategoryIds,
      competitorIds: selectedCompetitorIds,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      venue,
      matches,
      status: isDraft ? "DRAFT" : "ACTIVE",
      confederationId: params.id,
      createdAt: new Date().toISOString(),
    })

    // Redirect to tournaments page
    router.push(`/confederations/${params.id}/turniri`)
  }

  return (
    <WizardLayout
      steps={steps}
      currentStep={currentStep}
      completedSteps={completedSteps}
      isNextDisabled={isNextDisabled}
      onNext={handleNext}
      onBack={handleBack}
      confederationId={params.id}
    >
      {currentStep === 0 && (
        <Step1NameFormat name={name} format={format} onNameChange={setName} onFormatChange={setFormat} />
      )}

      {currentStep === 1 && (
        <Step2Categories
          categories={categories}
          selectedCategoryIds={selectedCategoryIds}
          onCategorySelect={setSelectedCategoryIds}
        />
      )}

      {currentStep === 2 && (
        <Step3Teams
          competitors={competitors}
          selectedCompetitorIds={selectedCompetitorIds}
          format={format}
          onCompetitorSelect={setSelectedCompetitorIds}
        />
      )}

      {currentStep === 3 && (
        <Step4TimeLocation
          startDate={startDate}
          endDate={endDate}
          venue={venue}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          onVenueChange={setVenue}
        />
      )}

      {currentStep === 4 && (
        <Step5Schedule format={format} matches={matches} competitors={competitors} onMatchesChange={setMatches} />
      )}

      {currentStep === 5 && (
        <Step6Review
          name={name}
          format={format}
          categoryIds={selectedCategoryIds}
          competitorIds={selectedCompetitorIds}
          startDate={startDate}
          endDate={endDate}
          venue={venue}
          onEditStep={handleEditStep}
          onSave={handleSaveTournament}
          categories={categories}
          competitors={competitors}
        />
      )}
    </WizardLayout>
  )
}
