"use client"

import { useState } from "react"
import { notFound } from "next/navigation"
import Link from "next/link"
import { DashboardLayout } from "@/components/dashboard-layout"
import { getConfederationById } from "@/lib/data"
import { getTournamentsByConfederationId, statusDisplayInfo } from "@/lib/tournament-data"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CupSoda, Plus, Calendar, Users, Trophy, ArrowRight } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { motion } from "framer-motion"

interface TurniriPageProps {
  params: {
    id: string
  }
}

export default function TurniriPage({ params }: TurniriPageProps) {
  const confederation = getConfederationById(params.id)

  if (!confederation) {
    notFound()
  }

  const tournaments = getTournamentsByConfederationId(params.id)
  const [hoveredCard, setHoveredCard] = useState<string | null>(null)

  return (
    <DashboardLayout confederationId={params.id} confederationName={confederation.name}>
      <div className="space-y-8">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
            <CupSoda className="h-8 w-8 text-amber-700" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Turniri i lige</h1>
            <p className="text-muted-foreground">Upravljanje turnirima i ligama</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* New Tournament Card */}
          <Link href={`/confederations/${params.id}/turniri/novi`}>
            <motion.div className="h-full" whileHover={{ scale: 1.03, transition: { duration: 0.2 } }}>
              <Card className="h-full border-dashed border-2 bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer overflow-hidden group">
                <CardContent className="p-0 h-full">
                  <div className="flex flex-col items-center justify-center h-full p-6 text-center">
                    <div className="mb-4 relative">
                      <div className="absolute inset-0 bg-amber-200 rounded-full blur-xl opacity-30 group-hover:opacity-60 transition-opacity"></div>
                      <div className="relative h-16 w-16 rounded-full bg-amber-100 flex items-center justify-center group-hover:bg-amber-200 transition-colors">
                        <Plus className="h-8 w-8 text-amber-700 group-hover:scale-110 transition-transform" />
                      </div>
                    </div>
                    <h3 className="text-xl font-bold mb-2 group-hover:text-amber-700 transition-colors">
                      Novi turnir / liga
                    </h3>
                    <p className="text-muted-foreground mb-4">Kreirajte novi turnir ili ligu za vaš savez</p>
                    <Button className="bg-amber-600 hover:bg-amber-700 group-hover:translate-y-0 translate-y-1 opacity-0 group-hover:opacity-100 transition-all">
                      Započni kreiranje
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </Link>

          {/* Tournament Cards */}
          {tournaments.map((tournament) => (
            <motion.div
              key={tournament.id}
              className="h-full"
              whileHover={{ scale: 1.03, transition: { duration: 0.2 } }}
              onHoverStart={() => setHoveredCard(tournament.id)}
              onHoverEnd={() => setHoveredCard(null)}
            >
              <Card className="h-full overflow-hidden border-2 hover:shadow-md transition-all">
                <CardHeader className="pb-2 relative">
                  <div className="absolute top-3 right-3">
                    <Badge variant="outline" className={`${statusDisplayInfo[tournament.status].color} px-2 py-0.5`}>
                      {statusDisplayInfo[tournament.status].name}
                    </Badge>
                  </div>
                  <CardTitle className="pr-20">{tournament.name}</CardTitle>
                  <CardDescription>
                    {formatDate(tournament.startDate)} - {formatDate(tournament.endDate)}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Trophy className="h-4 w-4 text-amber-600" />
                      <span>
                        {tournament.format === "ROUND_ROBIN"
                          ? "Liga (svatko sa svakim)"
                          : tournament.format === "SINGLE_ELIMINATION"
                            ? "Jedno ispadanje"
                            : tournament.format === "DOUBLE_ELIMINATION"
                              ? "Dvaput ispadanje"
                              : "Grupe + nokaut"}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="h-4 w-4 text-blue-600" />
                      <span>
                        Trajanje:{" "}
                        {Math.ceil(
                          (new Date(tournament.endDate).getTime() - new Date(tournament.startDate).getTime()) /
                            (1000 * 60 * 60 * 24),
                        )}{" "}
                        dana
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="h-4 w-4 text-emerald-600" />
                      <span>{tournament.competitorIds.length} natjecatelja</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Link href={`/confederations/${params.id}/turniri/${tournament.id}`} className="w-full">
                    <Button variant="outline" className="w-full">
                      Upravljaj turnirom
                    </Button>
                  </Link>
                </CardFooter>

                {/* Animated background gradient */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br from-amber-100/30 to-blue-100/30 opacity-0 transition-opacity duration-300 pointer-events-none ${hoveredCard === tournament.id ? "opacity-100" : ""}`}
                ></div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  )
}
