import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { confederations } from "@/lib/data"
import { getSportIcon } from "@/lib/sport-icons"

export default function ConfederationsPage() {
  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Sportski savezi</h1>
        <Button>Kreiraj novi savez</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {confederations.map((confederation) => {
          const SportIcon = getSportIcon(confederation.sport)

          return (
            <Card key={confederation.id} className="overflow-hidden transition-all hover:shadow-md">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle>{confederation.name}</CardTitle>
                  <SportIcon className="h-6 w-6 text-primary" />
                </div>
                <CardDescription>{confederation.sport}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{confederation.description || "Nema opisa"}</p>
              </CardContent>
              <CardFooter className="pt-2">
                <Link href={`/confederations/${confederation.id}/home`} className="w-full">
                  <Button variant="outline" className="w-full">
                    Upravljaj savezom
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
