import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

type GenderType = "M" | "F" | "MIX" | string

interface CategoryBadgeProps {
  name: string
  gender?: GenderType
  ageGroup?: string
  className?: string
  size?: "default" | "sm"
}

export function CategoryBadge({ name, gender, ageGroup, className, size = "default" }: CategoryBadgeProps) {
  const getGenderColor = (gender: GenderType) => {
    switch (gender) {
      case "M":
        return "bg-sky-100 text-sky-800 hover:bg-sky-100 border-sky-200"
      case "F":
        return "bg-pink-100 text-pink-800 hover:bg-pink-100 border-pink-200"
      case "MIX":
        return "bg-purple-100 text-purple-800 hover:bg-purple-100 border-purple-200"
      default:
        return ""
    }
  }

  const sizeClasses = {
    default: "px-2.5 py-0.5 text-xs",
    sm: "px-2 py-0.5 text-[10px]",
  }

  return (
    <Badge
      variant="outline"
      className={cn(sizeClasses[size], "font-medium rounded-md", gender ? getGenderColor(gender) : "", className)}
    >
      {name}
      {ageGroup && <span className="ml-1 opacity-70">({ageGroup})</span>}
    </Badge>
  )
}
