"use client"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useForm } from "react-hook-form"
import type { Category } from "@/lib/data"

interface CategoryFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  category?: Category
  confederationId: string
  onSubmit: (data: Partial<Category>) => void
}

export function CategoryForm({ open, onOpenChange, category, confederationId, onSubmit }: CategoryFormProps) {
  const form = useForm<Partial<Category>>({
    defaultValues: category || {
      name: "",
      ageGroup: "",
      gender: "M",
      weightClass: "",
      confederationId,
    },
  })

  const handleSubmit = (data: Partial<Category>) => {
    onSubmit(data)
    onOpenChange(false)
    form.reset()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{category ? "Uredi kategoriju" : "Dodaj novu kategoriju"}</DialogTitle>
          <DialogDescription>
            {category ? "Uredite detalje postojeće kategorije." : "Unesite detalje za novu kategoriju."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Naziv</FormLabel>
                  <FormControl>
                    <Input placeholder="Npr. Seniori" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="ageGroup"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Dobna skupina</FormLabel>
                  <FormControl>
                    <Input placeholder="Npr. 18+" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="gender"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Spol</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Odaberite spol" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="M">Muški</SelectItem>
                      <SelectItem value="F">Ženski</SelectItem>
                      <SelectItem value="MIX">Mješovito</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="weightClass"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Težinska kategorija (opcionalno)</FormLabel>
                  <FormControl>
                    <Input placeholder="Npr. do 60kg" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="submit">{category ? "Spremi promjene" : "Dodaj kategoriju"}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
