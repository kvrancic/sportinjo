"use client"

import type React from "react"

import { useState } from "react"
import { TableRow, TableCell } from "@/components/ui/table"
import { cn } from "@/lib/utils"

interface CollapsibleTableRowProps {
  children: React.ReactNode
  expandedContent: React.ReactNode
  isCompact?: boolean
  className?: string
}

export function CollapsibleTableRow({
  children,
  expandedContent,
  isCompact = false,
  className,
}: CollapsibleTableRowProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <>
      <TableRow
        className={cn(
          "group cursor-pointer hover:bg-muted/50 transition-colors",
          isCompact && "h-12",
          isExpanded && "bg-muted/30",
          className,
        )}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {children}
      </TableRow>
      {isExpanded && (
        <TableRow className="bg-muted/20 border-t-0">
          <TableCell colSpan={100} className="p-0">
            <div className="p-4 border-t border-dashed">{expandedContent}</div>
          </TableCell>
        </TableRow>
      )}
    </>
  )
}
