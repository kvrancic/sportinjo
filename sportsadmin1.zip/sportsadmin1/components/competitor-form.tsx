"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox, CheckboxIndicator } from "@radix-ui/react-checkbox"
import { useForm } from "react-hook-form"
import type { Competitor, Category } from "@/lib/data"
import { Check } from "lucide-react"

interface CompetitorFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  competitor?: Competitor
  confederationId: string
  categories: Category[]
  onSubmit: (data: Partial<Competitor>) => void
}

export function CompetitorForm({
  open,
  onOpenChange,
  competitor,
  confederationId,
  categories,
  onSubmit,
}: CompetitorFormProps) {
  const form = useForm<Partial<Competitor>>({
    defaultValues: competitor || {
      name: "",
      type: "TEAM",
      categoryIds: [],
      confederationId,
      city: "",
      coach: "",
    },
  })

  const [selectedCategories, setSelectedCategories] = useState<string[]>(competitor?.categoryIds || [])

  const handleSubmit = (data: Partial<Competitor>) => {
    const formData = {
      ...data,
      categoryIds: selectedCategories,
    }
    onSubmit(formData)
    onOpenChange(false)
    form.reset()
    setSelectedCategories([])
  }

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{competitor ? "Uredi natjecatelja" : "Dodaj novog natjecatelja"}</DialogTitle>
          <DialogDescription>
            {competitor ? "Uredite detalje postojećeg natjecatelja." : "Unesite detalje za novog natjecatelja."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Naziv</FormLabel>
                  <FormControl>
                    <Input placeholder="Npr. NK Dinamo" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tip</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Odaberite tip" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="TEAM">Ekipa</SelectItem>
                      <SelectItem value="INDIVIDUAL">Pojedinac</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormItem>
              <FormLabel>Kategorije</FormLabel>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={category.id}
                      checked={selectedCategories.includes(category.id)}
                      onCheckedChange={() => toggleCategory(category.id)}
                      className="h-4 w-4 rounded border border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                    >
                      <CheckboxIndicator>
                        <Check className="h-3 w-3" />
                      </CheckboxIndicator>
                    </Checkbox>
                    <label
                      htmlFor={category.id}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {category.name}
                    </label>
                  </div>
                ))}
              </div>
            </FormItem>
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Grad</FormLabel>
                  <FormControl>
                    <Input placeholder="Npr. Zagreb" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="coach"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Trener</FormLabel>
                  <FormControl>
                    <Input placeholder="Npr. Ivan Horvat" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="submit">{competitor ? "Spremi promjene" : "Dodaj natjecatelja"}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
