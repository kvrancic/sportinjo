import type React from "react"
import Link from "next/link"
import { MainNav } from "@/components/main-nav"
import { Button } from "@/components/ui/button"
import { ChevronLeft } from "lucide-react"
import { getSportIcon } from "@/lib/sport-icons"
import { getConfederationById } from "@/lib/data"

interface DashboardLayoutProps {
  children: React.ReactNode
  confederationId: string
  confederationName: string
}

export function DashboardLayout({ children, confederationId, confederationName }: DashboardLayoutProps) {
  const confederation = getConfederationById(confederationId)
  const SportIcon = confederation ? getSportIcon(confederation.sport) : null

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="hidden lg:flex flex-col w-64 border-r bg-white p-4">
        <div className="mb-6">
          <Link href="/confederations">
            <Button variant="ghost" size="sm" className="flex items-center gap-1">
              <ChevronLeft className="h-4 w-4" />
              <span>Natrag na saveze</span>
            </Button>
          </Link>
        </div>
        <div className="mb-6 px-3">
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-lg font-semibold">{confederationName}</h2>
          </div>
          <p className="text-sm text-muted-foreground">Admin portal</p>
        </div>
        <MainNav confederationId={confederationId} />
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-auto">
        <main className="p-6">{children}</main>
      </div>
    </div>
  )
}
