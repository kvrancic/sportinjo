"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BarChart3, Calendar, Home, ListChecks, Medal, Trophy, Users, CupSoda } from "lucide-react"
import { getConfederationById } from "@/lib/data"
import { getSportIcon } from "@/lib/sport-icons"

interface NavItem {
  title: string
  href: string
  icon: React.ReactNode
}

interface MainNavProps {
  confederationId: string
}

export function MainNav({ confederationId }: MainNavProps) {
  const pathname = usePathname()
  const confederation = getConfederationById(confederationId)
  const SportIcon = confederation ? getSportIcon(confederation.sport) : null

  const navItems: NavItem[] = [
    {
      title: "Početna",
      href: `/confederations/${confederationId}/home`,
      icon: <Home className="h-5 w-5" />,
    },
    {
      title: "Kategorije",
      href: `/confederations/${confederationId}/categories`,
      icon: <ListChecks className="h-5 w-5" />,
    },
    {
      title: "Natjecatelji",
      href: `/confederations/${confederationId}/competitors`,
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Kalendar",
      href: `/confederations/${confederationId}/calendar`,
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      title: "Rezultati",
      href: `/confederations/${confederationId}/results`,
      icon: <Medal className="h-5 w-5" />,
    },
    {
      title: "Poredak",
      href: `/confederations/${confederationId}/standings`,
      icon: <Trophy className="h-5 w-5" />,
    },
    {
      title: "Statistika",
      href: `/confederations/${confederationId}/statistics`,
      icon: <BarChart3 className="h-5 w-5" />,
    },
    {
      title: "Turniri",
      href: `/confederations/${confederationId}/turniri`,
      icon: <CupSoda className="h-5 w-5" />,
    },
  ]

  return (
    <nav className="flex flex-col space-y-1 w-full">
      {navItems.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={cn(
            "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
            pathname === item.href || pathname.startsWith(`${item.href}/`)
              ? "bg-primary text-primary-foreground"
              : "hover:bg-muted",
          )}
        >
          {item.icon}
          {item.title}
        </Link>
      ))}
    </nav>
  )
}
