"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useForm } from "react-hook-form"
import type { Match, Category, Competitor } from "@/lib/data"

interface MatchFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  match?: Match
  confederationId: string
  categories: Category[]
  competitors: Competitor[]
  onSubmit: (data: Partial<Match>) => void
}

export function MatchForm({
  open,
  onOpenChange,
  match,
  confederationId,
  categories,
  competitors,
  onSubmit,
}: MatchFormProps) {
  const form = useForm<Partial<Match>>({
    defaultValues: match || {
      date: new Date().toISOString().slice(0, 16),
      venue: "",
      categoryId: "",
      homeCompetitorId: "",
      awayCompetitorId: "",
      confederationId,
      status: "SCHEDULED",
    },
  })

  const [selectedCategoryId, setSelectedCategoryId] = useState<string>(match?.categoryId || "")

  const filteredCompetitors = selectedCategoryId
    ? competitors.filter((comp) => comp.categoryIds.includes(selectedCategoryId))
    : competitors

  const handleSubmit = (data: Partial<Match>) => {
    onSubmit(data)
    onOpenChange(false)
    form.reset()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{match ? "Uredi događaj" : "Dodaj novi događaj"}</DialogTitle>
          <DialogDescription>
            {match ? "Uredite detalje postojećeg događaja." : "Unesite detalje za novi događaj."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Datum i vrijeme</FormLabel>
                  <FormControl>
                    <Input type="datetime-local" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="venue"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Lokacija</FormLabel>
                  <FormControl>
                    <Input placeholder="Npr. Stadion Maksimir" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kategorija</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      field.onChange(value)
                      setSelectedCategoryId(value)
                    }}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Odaberite kategoriju" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="homeCompetitorId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Domaćin</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Odaberite domaćina" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {filteredCompetitors.map((competitor) => (
                        <SelectItem key={competitor.id} value={competitor.id}>
                          {competitor.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="awayCompetitorId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Gost</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Odaberite gosta" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {filteredCompetitors.map((competitor) => (
                        <SelectItem key={competitor.id} value={competitor.id}>
                          {competitor.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="submit">{match ? "Spremi promjene" : "Dodaj događaj"}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
