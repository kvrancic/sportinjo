import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface QuickLinkCardProps {
  title: string
  href: string
  icon: LucideIcon
  className?: string
  variant?: "default" | "primary" | "success" | "warning" | "danger" | "info"
}

export function QuickLinkCard({ title, href, icon: Icon, className, variant = "default" }: QuickLinkCardProps) {
  const variantStyles = {
    default: "",
    primary: "border-primary/20 hover:border-primary/30",
    success: "border-emerald-500/20 hover:border-emerald-500/30",
    warning: "border-amber-500/20 hover:border-amber-500/30",
    danger: "border-rose-500/20 hover:border-rose-500/30",
    info: "border-sky-500/20 hover:border-sky-500/30",
  }

  const iconStyles = {
    default: "text-muted-foreground group-hover:text-foreground",
    primary: "text-primary group-hover:text-primary",
    success: "text-emerald-500 group-hover:text-emerald-600",
    warning: "text-amber-500 group-hover:text-amber-600",
    danger: "text-rose-500 group-hover:text-rose-600",
    info: "text-sky-500 group-hover:text-sky-600",
  }

  const bgStyles = {
    default: "hover:bg-muted/50",
    primary: "hover:bg-primary/5",
    success: "hover:bg-emerald-500/5",
    warning: "hover:bg-amber-500/5",
    danger: "hover:bg-rose-500/5",
    info: "hover:bg-sky-500/5",
  }

  return (
    <Link href={href} className="group">
      <Card className={cn("transition-all hover:shadow-md", variantStyles[variant], bgStyles[variant], className)}>
        <CardContent className="flex flex-col items-center justify-center p-6">
          <Icon className={cn("h-8 w-8 mb-2", iconStyles[variant])} />
          <span className="text-sm font-medium text-center group-hover:font-semibold transition-all">{title}</span>
        </CardContent>
      </Card>
    </Link>
  )
}
