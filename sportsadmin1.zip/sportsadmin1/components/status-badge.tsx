import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

type StatusType = "SCHEDULED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED" | string

interface StatusBadgeProps {
  status: StatusType
  className?: string
  size?: "default" | "sm"
}

export function StatusBadge({ status, className, size = "default" }: StatusBadgeProps) {
  const getStatusLabel = (status: StatusType) => {
    switch (status) {
      case "SCHEDULED":
        return "Zakazano"
      case "IN_PROGRESS":
        return "U tijeku"
      case "COMPLETED":
        return "Završeno"
      case "CANCELLED":
        return "Otkazano"
      default:
        return status
    }
  }

  const getStatusVariant = (status: StatusType) => {
    switch (status) {
      case "SCHEDULED":
        return "info"
      case "IN_PROGRESS":
        return "warning"
      case "COMPLETED":
        return "success"
      case "CANCELLED":
        return "destructive"
      default:
        return "default"
    }
  }

  const sizeClasses = {
    default: "px-2.5 py-0.5 text-xs",
    sm: "px-2 py-0.5 text-[10px]",
  }

  return (
    <Badge variant={getStatusVariant(status)} className={cn(sizeClasses[size], "font-medium rounded-md", className)}>
      {getStatusLabel(status)}
    </Badge>
  )
}
