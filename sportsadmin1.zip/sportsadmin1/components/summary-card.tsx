import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface SummaryCardProps {
  title: string
  value: string | number
  icon: LucideIcon
  description?: string
  className?: string
  trend?: "up" | "down" | "neutral"
  trendValue?: string
  variant?: "default" | "primary" | "success" | "warning" | "danger" | "info"
}

export function SummaryCard({
  title,
  value,
  icon: Icon,
  description,
  className,
  trend,
  trendValue,
  variant = "default",
}: SummaryCardProps) {
  const variantStyles = {
    default: "",
    primary: "border-primary/20",
    success: "border-emerald-500/20",
    warning: "border-amber-500/20",
    danger: "border-rose-500/20",
    info: "border-sky-500/20",
  }

  const iconStyles = {
    default: "text-muted-foreground",
    primary: "text-primary",
    success: "text-emerald-500",
    warning: "text-amber-500",
    danger: "text-rose-500",
    info: "text-sky-500",
  }

  const bgStyles = {
    default: "",
    primary: "bg-primary/5",
    success: "bg-emerald-500/5",
    warning: "bg-amber-500/5",
    danger: "bg-rose-500/5",
    info: "bg-sky-500/5",
  }

  const trendStyles = {
    up: "text-emerald-500",
    down: "text-rose-500",
    neutral: "text-muted-foreground",
  }

  return (
    <Card className={cn(variantStyles[variant], bgStyles[variant], "transition-all hover:shadow-md", className)}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className={cn("h-8 w-8 rounded-full flex items-center justify-center", bgStyles[variant])}>
          <Icon className={cn("h-5 w-5", iconStyles[variant])} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center mt-1">
          {description && <p className="text-xs text-muted-foreground">{description}</p>}
          {trend && trendValue && (
            <div className={cn("ml-auto text-xs font-medium flex items-center gap-1", trendStyles[trend])}>
              {trend === "up" && <span>↑</span>}
              {trend === "down" && <span>↓</span>}
              {trendValue}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
