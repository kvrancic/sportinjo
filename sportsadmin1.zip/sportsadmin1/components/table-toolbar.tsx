"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, SlidersHorizontal, LayoutGrid, LayoutList } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"

interface TableToolbarProps {
  searchPlaceholder?: string
  onSearchChange: (value: string) => void
  onCompactChange: (isCompact: boolean) => void
  onColumnVisibilityChange?: (column: string, isVisible: boolean) => void
  availableColumns?: { id: string; title: string }[]
  className?: string
  visibleColumns?: string[]
}

export function TableToolbar({
  searchPlaceholder = "Pretraži...",
  onSearchChange,
  onCompactChange,
  onColumnVisibilityChange,
  availableColumns = [],
  className,
  visibleColumns = [],
}: TableToolbarProps) {
  const [isCompact, setIsCompact] = useState(false)

  const handleCompactToggle = () => {
    const newCompactState = !isCompact
    setIsCompact(newCompactState)
    onCompactChange(newCompactState)
  }

  return (
    <div className={cn("flex flex-col sm:flex-row items-center gap-4 mb-4", className)}>
      <div className="relative w-full sm:w-auto flex-1 max-w-sm">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder={searchPlaceholder} className="pl-8" onChange={(e) => onSearchChange(e.target.value)} />
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className={cn(isCompact ? "bg-muted" : "")}
          onClick={handleCompactToggle}
          title={isCompact ? "Standardni prikaz" : "Kompaktni prikaz"}
        >
          {isCompact ? <LayoutGrid className="h-4 w-4" /> : <LayoutList className="h-4 w-4" />}
          <span className="ml-2 hidden sm:inline">{isCompact ? "Standardni" : "Kompaktni"}</span>
        </Button>

        {availableColumns.length > 0 && onColumnVisibilityChange && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" title="Prikaži/sakrij stupce">
                <SlidersHorizontal className="h-4 w-4" />
                <span className="ml-2 hidden sm:inline">Stupci</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {availableColumns.map((column) => (
                <DropdownMenuCheckboxItem
                  key={column.id}
                  checked={visibleColumns.includes(column.id)}
                  onCheckedChange={(checked) => onColumnVisibilityChange(column.id, checked)}
                >
                  {column.title}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </div>
  )
}
