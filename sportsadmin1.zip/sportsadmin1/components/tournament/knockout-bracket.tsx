"use client"

import { useMemo } from "react"
import Image from "next/image"
import { format } from "date-fns"
import type { TournamentMatch } from "@/lib/tournament-data"
import { type Competitor, getCompetitorById } from "@/lib/data"
import { getTeamLogo } from "@/lib/team-logos"
import { Button } from "@/components/ui/button"
import { Edit, Trash2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

type Props = {
  matches: TournamentMatch[]
  competitors: Competitor[]
  onEdit: (m: TournamentMatch) => void
  onDelete: (id: string) => void
  openEditDialog: (o: boolean) => void
}

// Helper function to get round name
function getRoundName(round: number, maxRound: number): string {
  if (round === maxRound) return "Finale"
  if (round === maxRound - 1) return "Polufinale"
  if (round === maxRound - 2) return "Četvrtfinale"
  return `Runda ${round}`
}

export default function KnockoutBracket({ matches, competitors, onEdit, onDelete, openEditDialog }: Props) {
  // Group matches by round
  const matchesByRound = useMemo(() => {
    const result: Record<number, TournamentMatch[]> = {}

    matches.forEach((match) => {
      if (!result[match.round]) {
        result[match.round] = []
      }
      result[match.round].push(match)
    })

    return result
  }, [matches])

  // Get sorted rounds
  const rounds = useMemo(() => {
    return Object.keys(matchesByRound)
      .map(Number)
      .sort((a, b) => a - b)
  }, [matchesByRound])

  // Get max round
  const maxRound = useMemo(() => {
    return rounds.length > 0 ? Math.max(...rounds) : 0
  }, [rounds])

  if (matches.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Nema utakmica za prikaz. Utakmice će biti generirane nakon što završite kreiranje turnira.
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="overflow-x-auto pb-4">
        <div className="flex space-x-4" style={{ minWidth: rounds.length * 300 + "px" }}>
          {rounds.map((round) => (
            <div key={round} className="flex-1 min-w-[280px]">
              <div className="mb-3 text-center font-semibold">{getRoundName(round, maxRound)}</div>

              <div className="space-y-4">
                {matchesByRound[round].map((match) => {
                  const homeTeam = getCompetitorById(match.homeCompetitorId)
                  const awayTeam = getCompetitorById(match.awayCompetitorId)

                  return (
                    <Card key={match.id} className="overflow-hidden">
                      <CardContent className="p-3">
                        <div className="flex justify-between items-center mb-2">
                          <div className="text-xs text-muted-foreground">
                            {format(new Date(match.date), "dd.MM. HH:mm")}
                          </div>
                          <div className="flex space-x-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => {
                                onEdit(match)
                                openEditDialog(true)
                              }}
                            >
                              <Edit className="h-3 w-3" />
                              <span className="sr-only">Uredi</span>
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-destructive"
                              onClick={() => onDelete(match.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                              <span className="sr-only">Obriši</span>
                            </Button>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center">
                            <div className="h-6 w-6 rounded-full overflow-hidden bg-muted flex-shrink-0">
                              <Image
                                src={getTeamLogo(match.homeCompetitorId) || "/placeholder.svg"}
                                alt={homeTeam?.name || ""}
                                width={24}
                                height={24}
                                className="object-cover"
                              />
                            </div>
                            <div className="ml-2 flex-1 truncate">{homeTeam?.name || "TBD"}</div>
                            {match.result && <div className="font-semibold ml-2">{match.result.homeScore}</div>}
                          </div>

                          <div className="flex items-center">
                            <div className="h-6 w-6 rounded-full overflow-hidden bg-muted flex-shrink-0">
                              <Image
                                src={getTeamLogo(match.awayCompetitorId) || "/placeholder.svg"}
                                alt={awayTeam?.name || ""}
                                width={24}
                                height={24}
                                className="object-cover"
                              />
                            </div>
                            <div className="ml-2 flex-1 truncate">{awayTeam?.name || "TBD"}</div>
                            {match.result && <div className="font-semibold ml-2">{match.result.awayScore}</div>}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
