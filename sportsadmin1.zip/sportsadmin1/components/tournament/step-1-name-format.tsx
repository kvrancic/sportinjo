"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dice5, Trophy } from "lucide-react"
import { type TournamentFormat, formatDisplayNames, generateRandomTournamentName } from "@/lib/tournament-data"
import { motion } from "framer-motion"

interface Step1Props {
  name: string
  format: TournamentFormat
  onNameChange: (name: string) => void
  onFormatChange: (format: TournamentFormat) => void
}

export function Step1NameFormat({ name, format, onNameChange, onFormatChange }: Step1Props) {
  const [isNameValid, setIsNameValid] = useState(false)

  useEffect(() => {
    setIsNameValid(name.length >= 3)
  }, [name])

  const handleGenerateRandomName = () => {
    onNameChange(generateRandomTournamentName())
  }

  return (
    <div className="space-y-8">
      {/* Hero banner that echoes the name */}
      <motion.div
        className="relative overflow-hidden rounded-lg bg-gradient-to-r from-amber-500 to-amber-700 text-white p-8 shadow-lg"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="absolute top-0 right-0 opacity-10">
          <Trophy className="h-64 w-64 -mt-8 -mr-8" />
        </div>
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{name || "Novi turnir"}</h1>
        <p className="text-amber-100 max-w-2xl">
          {format ? formatDisplayNames[format] : "Odaberite format natjecanja"}
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="tournament-name">Naziv turnira</Label>
            <div className="flex gap-2">
              <Input
                id="tournament-name"
                placeholder="Npr. Prvenstvo Zagreba 2025"
                value={name}
                onChange={(e) => onNameChange(e.target.value)}
                className="flex-1"
              />
              <Button
                variant="outline"
                onClick={handleGenerateRandomName}
                className="flex items-center gap-2"
                title="Nasumično ime"
              >
                <Dice5 className="h-4 w-4" />
                <span className="hidden sm:inline">Nasumično ime</span>
              </Button>
            </div>
            {name && name.length < 3 && <p className="text-sm text-destructive">Naziv mora imati najmanje 3 znaka</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="tournament-format">Format natjecanja</Label>
            <Select value={format} onValueChange={(value) => onFormatChange(value as TournamentFormat)}>
              <SelectTrigger id="tournament-format">
                <SelectValue placeholder="Odaberite format natjecanja" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(formatDisplayNames).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Format natjecanja</h3>

              {format === "ROUND_ROBIN" && (
                <div className="space-y-4">
                  <div className="rounded-lg bg-muted p-4">
                    <h4 className="font-medium mb-2">Liga (svatko sa svakim)</h4>
                    <p className="text-sm text-muted-foreground">
                      Svaki natjecatelj igra protiv svakog drugog natjecatelja. Idealno za lige i prvenstva gdje je
                      važno da svi imaju jednake uvjete.
                    </p>
                  </div>
                  <div className="flex justify-center">
                    <div className="w-32 h-32 rounded-full border-4 border-amber-200 flex items-center justify-center relative">
                      <div className="absolute w-3 h-3 bg-amber-500 rounded-full top-0 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                      <div className="absolute w-3 h-3 bg-amber-500 rounded-full bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2"></div>
                      <div className="absolute w-3 h-3 bg-amber-500 rounded-full left-0 top-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                      <div className="absolute w-3 h-3 bg-amber-500 rounded-full right-0 top-1/2 translate-x-1/2 -translate-y-1/2"></div>
                      <div className="w-24 h-24 rounded-full border-2 border-amber-300 flex items-center justify-center">
                        <Trophy className="h-8 w-8 text-amber-500" />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {format === "SINGLE_ELIMINATION" && (
                <div className="space-y-4">
                  <div className="rounded-lg bg-muted p-4">
                    <h4 className="font-medium mb-2">Jedno ispadanje</h4>
                    <p className="text-sm text-muted-foreground">
                      Natjecatelji koji izgube utakmicu ispadaju iz natjecanja. Idealno za brze turnire i kup
                      natjecanja.
                    </p>
                  </div>
                  <div className="flex justify-center">
                    <div className="bracket-preview">
                      <svg width="200" height="120" viewBox="0 0 200 120">
                        <line x1="10" y1="20" x2="50" y2="20" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="10" y1="60" x2="50" y2="60" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="50" y1="20" x2="50" y2="60" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="50" y1="40" x2="90" y2="40" stroke="#d1d5db" strokeWidth="2" />

                        <line x1="110" y1="40" x2="150" y2="40" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="110" y1="80" x2="150" y2="80" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="150" y1="40" x2="150" y2="80" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="150" y1="60" x2="190" y2="60" stroke="#d1d5db" strokeWidth="2" />

                        <circle cx="10" cy="20" r="5" fill="#f59e0b" />
                        <circle cx="10" cy="60" r="5" fill="#f59e0b" />
                        <circle cx="110" cy="40" r="5" fill="#f59e0b" />
                        <circle cx="110" cy="80" r="5" fill="#f59e0b" />
                        <circle cx="190" cy="60" r="5" fill="#f59e0b" />
                      </svg>
                    </div>
                  </div>
                </div>
              )}

              {format === "DOUBLE_ELIMINATION" && (
                <div className="space-y-4">
                  <div className="rounded-lg bg-muted p-4">
                    <h4 className="font-medium mb-2">Dvaput ispadanje</h4>
                    <p className="text-sm text-muted-foreground">
                      Natjecatelji ispadaju nakon dva poraza. Pruža drugu šansu i više utakmica.
                    </p>
                  </div>
                  <div className="flex justify-center">
                    <div className="bracket-preview">
                      <svg width="200" height="150" viewBox="0 0 200 150">
                        {/* Winners bracket */}
                        <line x1="10" y1="20" x2="50" y2="20" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="10" y1="60" x2="50" y2="60" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="50" y1="20" x2="50" y2="60" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="50" y1="40" x2="90" y2="40" stroke="#d1d5db" strokeWidth="2" />

                        {/* Losers bracket */}
                        <line x1="10" y1="100" x2="50" y2="100" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="10" y1="140" x2="50" y2="140" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="50" y1="100" x2="50" y2="140" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="50" y1="120" x2="90" y2="120" stroke="#d1d5db" strokeWidth="2" />

                        {/* Final */}
                        <line x1="110" y1="40" x2="150" y2="40" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="110" y1="120" x2="150" y2="120" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="150" y1="40" x2="150" y2="120" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="150" y1="80" x2="190" y2="80" stroke="#d1d5db" strokeWidth="2" />

                        <circle cx="10" cy="20" r="4" fill="#f59e0b" />
                        <circle cx="10" cy="60" r="4" fill="#f59e0b" />
                        <circle cx="10" cy="100" r="4" fill="#f59e0b" />
                        <circle cx="10" cy="140" r="4" fill="#f59e0b" />
                        <circle cx="190" cy="80" r="4" fill="#f59e0b" />
                      </svg>
                    </div>
                  </div>
                </div>
              )}

              {format === "GROUP_KNOCKOUT" && (
                <div className="space-y-4">
                  <div className="rounded-lg bg-muted p-4">
                    <h4 className="font-medium mb-2">Grupe + nokaut</h4>
                    <p className="text-sm text-muted-foreground">
                      Natjecatelji su podijeljeni u grupe gdje igraju svatko sa svakim, a zatim najbolji iz svake grupe
                      nastavljaju u nokaut fazu.
                    </p>
                  </div>
                  <div className="flex justify-center">
                    <div className="bracket-preview">
                      <svg width="200" height="150" viewBox="0 0 200 150">
                        {/* Group A */}
                        <rect
                          x="10"
                          y="10"
                          width="40"
                          height="40"
                          rx="4"
                          fill="none"
                          stroke="#d1d5db"
                          strokeWidth="2"
                        />
                        <text x="30" y="35" textAnchor="middle" fontSize="12" fill="#6b7280">
                          A
                        </text>

                        {/* Group B */}
                        <rect
                          x="10"
                          y="60"
                          width="40"
                          height="40"
                          rx="4"
                          fill="none"
                          stroke="#d1d5db"
                          strokeWidth="2"
                        />
                        <text x="30" y="85" textAnchor="middle" fontSize="12" fill="#6b7280">
                          B
                        </text>

                        {/* Group C */}
                        <rect
                          x="10"
                          y="110"
                          width="40"
                          height="40"
                          rx="4"
                          fill="none"
                          stroke="#d1d5db"
                          strokeWidth="2"
                        />
                        <text x="30" y="135" textAnchor="middle" fontSize="12" fill="#6b7280">
                          C
                        </text>

                        {/* Knockout stage */}
                        <line x1="70" y1="30" x2="100" y2="30" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="70" y1="80" x2="100" y2="80" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="70" y1="130" x2="100" y2="130" stroke="#d1d5db" strokeWidth="2" />

                        <line x1="100" y1="30" x2="100" y2="80" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="100" y1="55" x2="130" y2="55" stroke="#d1d5db" strokeWidth="2" />

                        <line x1="100" y1="130" x2="130" y2="130" stroke="#d1d5db" strokeWidth="2" />

                        <line x1="150" y1="55" x2="150" y2="130" stroke="#d1d5db" strokeWidth="2" />
                        <line x1="150" y1="92.5" x2="180" y2="92.5" stroke="#d1d5db" strokeWidth="2" />

                        <circle cx="180" cy="92.5" r="4" fill="#f59e0b" />
                      </svg>
                    </div>
                  </div>
                </div>
              )}

              {!format && (
                <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                  <Trophy className="h-12 w-12 mb-4 text-muted" />
                  <p>Odaberite format natjecanja</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
