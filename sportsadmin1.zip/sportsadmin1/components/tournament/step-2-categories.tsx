"use client"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle } from "lucide-react"
import { motion } from "framer-motion"
import { type Category, getCategoryById } from "@/lib/data"
import { CategoryBadge } from "@/components/category-badge"

interface Step2Props {
  categories: Category[]
  selectedCategoryIds: string[]
  onCategorySelect: (categoryIds: string[]) => void
}

export function Step2Categories({ categories, selectedCategoryIds, onCategorySelect }: Step2Props) {
  const handleToggleCategory = (categoryId: string) => {
    onCategorySelect(
      selectedCategoryIds.includes(categoryId)
        ? selectedCategoryIds.filter((id) => id !== categoryId)
        : [...selectedCategoryIds, categoryId],
    )
  }

  const handleSelectAll = () => {
    onCategorySelect(categories.map((c) => c.id))
  }

  const handleDeselectAll = () => {
    onCategorySelect([])
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Odabir kategorija</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleSelectAll} className="text-xs">
                Odaberi sve
              </Button>
              <Button variant="outline" size="sm" onClick={handleDeselectAll} className="text-xs">
                Poništi sve
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((category) => {
              const isSelected = selectedCategoryIds.includes(category.id)

              return (
                <motion.div
                  key={category.id}
                  className={`relative h-40 cursor-pointer rounded-lg border bg-card text-card-foreground shadow-sm ${isSelected ? "ring-2 ring-primary" : ""}`}
                  whileHover={{ scale: 1.02 }}
                  onClick={() => handleToggleCategory(category.id)}
                >
                  <div className="p-6 flex flex-col h-full">
                    <div className="flex justify-between items-start">
                      <h3 className="font-semibold text-lg">{category.name}</h3>
                      <div
                        className={`h-6 w-6 rounded-full flex items-center justify-center ${isSelected ? "bg-primary text-primary-foreground" : "bg-muted"}`}
                      >
                        {isSelected && <CheckCircle className="h-4 w-4" />}
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <CategoryBadge name={category.ageGroup} gender={category.gender} />
                      {category.weightClass && (
                        <span className="inline-flex items-center rounded-md bg-gray-100 px-2 py-1 text-xs font-medium">
                          {category.weightClass}
                        </span>
                      )}
                    </div>
                    <div className="mt-2 space-y-2 text-sm">
                      <p>
                        <span className="font-medium">Dobna skupina:</span> {category.ageGroup}
                      </p>
                      <p>
                        <span className="font-medium">Spol:</span>{" "}
                        {category.gender === "M" ? "Muški" : category.gender === "F" ? "Ženski" : "Mješovito"}
                      </p>
                      {category.weightClass && (
                        <p>
                          <span className="font-medium">Težinska kategorija:</span> {category.weightClass}
                        </p>
                      )}
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </div>
        </div>

        <div className="w-full md:w-64 lg:w-80 space-y-4">
          <div className="rounded-lg border bg-card p-4">
            <h3 className="font-semibold mb-3">Trenutni odabir</h3>
            {selectedCategoryIds.length > 0 ? (
              <div className="space-y-2">
                {selectedCategoryIds.map((categoryId) => {
                  const category = getCategoryById(categoryId)
                  if (!category) return null

                  return (
                    <div key={categoryId} className="flex items-center justify-between group">
                      <div className="flex items-center gap-2">
                        <CategoryBadge name={category.name} gender={category.gender} size="sm" />
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleToggleCategory(categoryId)
                        }}
                      >
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  )
                })}
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground">
                <p>Nema odabranih kategorija</p>
              </div>
            )}
          </div>

          <div className="rounded-lg bg-amber-50 border border-amber-200 p-4">
            <h3 className="font-semibold text-amber-800 mb-2">Savjet</h3>
            <p className="text-sm text-amber-700">
              Odaberite kategorije za koje želite organizirati turnir. Možete odabrati više kategorija odjednom.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
