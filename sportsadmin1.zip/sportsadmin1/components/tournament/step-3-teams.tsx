"use client";

import type React from "react";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Search,
  Shuffle,
  RotateCcw,
  List,
  Info,
  AlertCircle,
  X,
} from "lucide-react";
import Image from "next/image";
import { getTeamLogo } from "@/lib/team-logos";
import type { Competitor } from "@/lib/data";
import type { TournamentFormat } from "@/lib/tournament-data";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface Step3Props {
  format: TournamentFormat;
  competitors: Competitor[];
  selectedCompetitorIds: string[];
  onCompetitorSelect: (competitorIds: string[]) => void;
}

export function Step3Teams({
  format,
  competitors,
  selectedCompetitorIds = [],
  onCompetitorSelect,
}: Step3Props) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState<"selection" | "explanation">(
    "selection"
  );
  const [draggedCompetitor, setDraggedCompetitor] = useState<string | null>(
    null
  );

  // Filter competitors based on search query
  const filteredCompetitors = useMemo(() => {
    if (!competitors || !Array.isArray(competitors)) return [];
    return competitors.filter((competitor) =>
      competitor?.name?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [competitors, searchQuery]);

  // Get selected competitors as full objects
  const selectedTeams = useMemo(() => {
    if (
      !competitors ||
      !Array.isArray(competitors) ||
      !selectedCompetitorIds ||
      !Array.isArray(selectedCompetitorIds)
    )
      return [];

    return selectedCompetitorIds
      .map((id) => competitors.find((c) => c.id === id))
      .filter(Boolean) as Competitor[];
  }, [competitors, selectedCompetitorIds]);

  // Handle competitor selection
  const toggleCompetitor = (competitorId: string) => {
    if (
      !competitorId ||
      !selectedCompetitorIds ||
      !Array.isArray(selectedCompetitorIds)
    )
      return;

    if (selectedCompetitorIds.includes(competitorId)) {
      onCompetitorSelect(
        selectedCompetitorIds.filter((id) => id !== competitorId)
      );
    } else {
      onCompetitorSelect([...selectedCompetitorIds, competitorId]);
    }
  };

  // Handle randomize
  const handleRandomize = () => {
    if (!competitors || !Array.isArray(competitors)) return;

    const shuffled = [...competitors]
      .sort(() => Math.random() - 0.5)
      .slice(0, getMinimumTeamsRequired())
      .map((c) => c.id);
    onCompetitorSelect(shuffled);
  };

  // Handle reset
  const handleReset = () => {
    onCompetitorSelect([]);
  };

  // Get minimum teams required based on format
  const getMinimumTeamsRequired = () => {
    if (!format) return 2;

    switch (format) {
      case "ROUND_ROBIN":
        return 3;
      case "SINGLE_ELIMINATION":
      case "DOUBLE_ELIMINATION":
        return 4;
      case "GROUP_KNOCKOUT":
        return 6;
      default:
        return 2;
    }
  };

  // Get ideal number of teams based on format
  const getIdealTeamsCount = () => {
    if (!format) return "8";

    switch (format) {
      case "ROUND_ROBIN":
        return "6-10";
      case "SINGLE_ELIMINATION":
      case "DOUBLE_ELIMINATION":
        return "8, 16, or 32";
      case "GROUP_KNOCKOUT":
        return "8, 12, or 16";
      default:
        return "8";
    }
  };

  // Handle drag start
  const handleDragStart = (competitorId: string) => {
    setDraggedCompetitor(competitorId);
  };

  // Handle drag over
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  // Handle drop
  const handleDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (
      !draggedCompetitor ||
      !selectedCompetitorIds ||
      !selectedCompetitorIds.includes(draggedCompetitor)
    )
      return;

    const newSelectedCompetitors = [...selectedCompetitorIds];
    const draggedIndex = newSelectedCompetitors.indexOf(draggedCompetitor);

    // Remove from old position
    newSelectedCompetitors.splice(draggedIndex, 1);
    // Insert at new position
    newSelectedCompetitors.splice(index, 0, draggedCompetitor);

    onCompetitorSelect(newSelectedCompetitors);
    setDraggedCompetitor(null);
  };

  // Helper function to get format display name
  function getFormatName(formatType: TournamentFormat): string {
    if (!formatType) return "Nepoznat format";

    switch (formatType) {
      case "ROUND_ROBIN":
        return "Liga (svatko sa svakim)";
      case "SINGLE_ELIMINATION":
        return "Jedno ispadanje";
      case "DOUBLE_ELIMINATION":
        return "Dvostruko ispadanje";
      case "GROUP_KNOCKOUT":
        return "Grupe + nokaut faza";
      default:
        return String(formatType);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Ekipe & ždrijeb</h2>
        <div className="flex gap-2">
          <Tabs
            value={activeTab}
            onValueChange={(value) =>
              setActiveTab(value as "selection" | "explanation")
            }
          >
            <TabsList>
              <TabsTrigger value="selection">Odabir ekipa</TabsTrigger>
              <TabsTrigger value="explanation">
                Objašnjenje ždrijeba
              </TabsTrigger>
            </TabsList>

            <TabsContent value="selection" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left column - Team selection */}
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle>Dostupne ekipe</CardTitle>
                      <div className="relative">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          type="search"
                          placeholder="Pretraži ekipe..."
                          className="pl-8 w-[200px]"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                    </div>
                    <CardDescription>
                      Odaberite ekipe koje će sudjelovati u turniru
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[400px] pr-4">
                      <div className="grid grid-cols-1 gap-2">
                        {filteredCompetitors.length === 0 ? (
                          <div className="text-center py-8 text-muted-foreground">
                            {searchQuery
                              ? "Nema rezultata za pretragu"
                              : "Nema dostupnih ekipa"}
                          </div>
                        ) : (
                          filteredCompetitors.map((competitor) => (
                            <div
                              key={competitor.id}
                              className={`flex items-center p-2 rounded-md cursor-pointer transition-colors ${
                                selectedCompetitorIds?.includes(competitor.id)
                                  ? "bg-primary/10 border-primary border"
                                  : "hover:bg-muted border border-transparent"
                              }`}
                              onClick={() => toggleCompetitor(competitor.id)}
                              draggable={selectedCompetitorIds?.includes(
                                competitor.id
                              )}
                              onDragStart={() => handleDragStart(competitor.id)}
                            >
                              <div className="h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                                <Image
                                  src={
                                    getTeamLogo(competitor.id) ||
                                    "/placeholder.svg?height=40&width=40&query=team"
                                  }
                                  alt={competitor.name || "Team"}
                                  width={40}
                                  height={40}
                                  className="object-cover"
                                />
                              </div>
                              <div className="ml-3 flex-1">
                                <div className="font-medium">
                                  {competitor.name || "Nepoznata ekipa"}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {competitor.city || ""}
                                </div>
                              </div>
                              {selectedCompetitorIds?.includes(
                                competitor.id
                              ) && (
                                <Badge variant="outline" className="ml-2">
                                  Odabrano
                                </Badge>
                              )}
                            </div>
                          ))
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>

                {/* Right column - Selected teams and bracket preview */}
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle>Odabrane ekipe</CardTitle>
                      <div className="flex gap-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={handleRandomize}
                              >
                                <Shuffle className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Nasumično rasporedi</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={handleReset}
                              >
                                <RotateCcw className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Resetiraj</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button variant="outline" size="icon">
                                <List className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Pregled liste</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </div>
                    <CardDescription>
                      Redoslijed ekipa određuje njihov položaj u ždrijebu.
                      Povucite ekipe za promjenu redoslijeda.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!selectedTeams || selectedTeams.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-[400px] border-2 border-dashed rounded-md p-6">
                        <div className="text-center text-muted-foreground">
                          <p>Odaberite ekipe s lijeve strane</p>
                          <p className="text-sm mt-2">
                            Preporučeni broj ekipa za{" "}
                            {format === "ROUND_ROBIN" ? "ligu" : "turnir"}:{" "}
                            {getIdealTeamsCount()}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {selectedTeams.length < getMinimumTeamsRequired() && (
                          <Alert variant="destructive">
                            <AlertCircle className="h-4 w-4" />
                            <AlertTitle>Nedovoljno ekipa</AlertTitle>
                            <AlertDescription>
                              Za format{" "}
                              {format === "ROUND_ROBIN" ? "lige" : "turnira"}{" "}
                              potrebno je najmanje {getMinimumTeamsRequired()}{" "}
                              ekipe.
                            </AlertDescription>
                          </Alert>
                        )}

                        <ScrollArea className="h-[350px] pr-4">
                          <div className="space-y-2">
                            {selectedTeams.map((team, index) => (
                              <div
                                key={team.id}
                                className="flex items-center p-3 rounded-md bg-muted/50 border border-muted-foreground/20"
                                draggable
                                onDragStart={() => handleDragStart(team.id)}
                                onDragOver={handleDragOver}
                                onDrop={(e) => handleDrop(e, index)}
                              >
                                <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-medium mr-3">
                                  {index + 1}
                                </div>
                                <div className="h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                                  <Image
                                    src={
                                      getTeamLogo(team.id) ||
                                      "/placeholder.svg?height=40&width=40&query=team"
                                    }
                                    alt={team.name || "Team"}
                                    width={40}
                                    height={40}
                                    className="object-cover"
                                  />
                                </div>
                                <div className="ml-3 flex-1">
                                  <div className="font-medium">
                                    {team.name || "Nepoznata ekipa"}
                                  </div>
                                  <div className="text-xs text-muted-foreground">
                                    {team.city || ""}
                                  </div>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => toggleCompetitor(team.id)}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="explanation" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>
                    Objašnjenje ždrijeba za format: {getFormatName(format)}
                  </CardTitle>
                  <CardDescription>
                    Kako će ekipe biti raspoređene u turniru
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {format === "ROUND_ROBIN" && (
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="bg-primary/10 p-3 rounded-full">
                          <Info className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium">
                            Liga (svatko sa svakim)
                          </h3>
                          <p className="text-muted-foreground mt-1">
                            U liga formatu, svaka ekipa igra protiv svake druge
                            ekipe jednom (ili dvaput za dvokružnu ligu). Ovo je
                            najpravedniji format jer svaka ekipa ima jednaku
                            priliku igrati protiv svih ostalih.
                          </p>
                        </div>
                      </div>

                      <div className="bg-muted/30 p-4 rounded-lg">
                        <h4 className="font-medium mb-2">
                          Kako se generira raspored:
                        </h4>
                        <ol className="list-decimal list-inside space-y-2 text-sm">
                          <li>
                            Ekipe se raspoređuju u kružni raspored (algoritam
                            kružnog rasporeda).
                          </li>
                          <li>
                            Za svaku rundu, prva ekipa ostaje fiksna, a ostale
                            rotiraju u smjeru kazaljke na satu.
                          </li>
                          <li>
                            Parovi se formiraju spajanjem ekipa koje su nasuprot
                            jedna drugoj u kružnom rasporedu.
                          </li>
                          <li>
                            Domaćinstva se automatski izmjenjuju između rundi
                            kako bi se osigurala ravnomjerna raspodjela.
                          </li>
                        </ol>
                      </div>

                      <div className="flex justify-center p-4">
                        <svg width="300" height="300" viewBox="0 0 300 300">
                          {/* Circle */}
                          <circle
                            cx="150"
                            cy="150"
                            r="100"
                            fill="none"
                            stroke="#d1d5db"
                            strokeWidth="2"
                          />

                          {/* Teams */}
                          {[0, 1, 2, 3, 4, 5].map((i) => {
                            const angle = (i * Math.PI * 2) / 6;
                            const x = 150 + Math.cos(angle) * 100;
                            const y = 150 + Math.sin(angle) * 100;

                            return (
                              <g key={i}>
                                <circle
                                  cx={x}
                                  cy={y}
                                  r="20"
                                  fill="#fff"
                                  stroke="#d1d5db"
                                  strokeWidth="1.5"
                                />
                                <text
                                  x={x}
                                  y={y}
                                  textAnchor="middle"
                                  dominantBaseline="middle"
                                  fontSize="12"
                                  fontWeight="bold"
                                >
                                  {String.fromCharCode(65 + i)}
                                </text>
                              </g>
                            );
                          })}

                          {/* Connection lines */}
                          <line
                            x1="150"
                            y1="50"
                            x2="150"
                            y2="250"
                            stroke="#d1d5db"
                            strokeWidth="1"
                            strokeDasharray="4"
                          />
                          <line
                            x1="50"
                            y1="150"
                            x2="250"
                            y2="150"
                            stroke="#d1d5db"
                            strokeWidth="1"
                            strokeDasharray="4"
                          />
                          <line
                            x1="75"
                            y1="75"
                            x2="225"
                            y2="225"
                            stroke="#d1d5db"
                            strokeWidth="1"
                            strokeDasharray="4"
                          />
                          <line
                            x1="75"
                            y1="225"
                            x2="225"
                            y2="75"
                            stroke="#d1d5db"
                            strokeWidth="1"
                            strokeDasharray="4"
                          />

                          {/* Legend */}
                          <text
                            x="150"
                            y="280"
                            textAnchor="middle"
                            fontSize="12"
                          >
                            Svaka ekipa igra protiv svake druge ekipe
                          </text>
                        </svg>
                      </div>

                      <div className="bg-muted/30 p-4 rounded-lg">
                        <h4 className="font-medium mb-2">
                          Primjer lige s 6 ekipa:
                        </h4>
                        <p className="text-sm mb-2">
                          Svaka ekipa igra 5 utakmica (ukupno 15 utakmica u
                          ligi).
                        </p>
                        <div className="grid grid-cols-3 gap-2 text-sm">
                          <div className="bg-white p-2 rounded border">
                            <div className="font-medium">Runda 1</div>
                            <div>A vs F</div>
                            <div>B vs E</div>
                            <div>C vs D</div>
                          </div>
                          <div className="bg-white p-2 rounded border">
                            <div className="font-medium">Runda 2</div>
                            <div>A vs E</div>
                            <div>F vs D</div>
                            <div>B vs C</div>
                          </div>
                          <div className="bg-white p-2 rounded border">
                            <div className="font-medium">Runda 3</div>
                            <div>A vs D</div>
                            <div>E vs C</div>
                            <div>F vs B</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {format === "SINGLE_ELIMINATION" && (
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="bg-primary/10 p-3 rounded-full">
                          <Info className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium">
                            Jedno ispadanje (Single Elimination)
                          </h3>
                          <p className="text-muted-foreground mt-1">
                            U formatu s jednim ispadanjem, ekipa ispada iz
                            turnira nakon prvog poraza. Ovaj format je
                            najjednostavniji i najbrži za organizaciju, ali može
                            biti manje pravedan jer ekipa može ispasti nakon
                            samo jedne loše utakmice.
                          </p>
                        </div>
                      </div>

                      <div className="bg-muted/30 p-4 rounded-lg">
                        <h4 className="font-medium mb-2">
                          Kako se generira ždrijeb:
                        </h4>
                        <ol className="list-decimal list-inside space-y-2 text-sm">
                          <li>
                            Ekipe se raspoređuju prema njihovom redoslijedu na
                            listi (nositelji).
                          </li>
                          <li>
                            Broj ekipa se zaokružuje na najbližu potenciju broja
                            2 (4, 8, 16, 32...) dodavanjem slobodnih prolaza
                            (bye) ako je potrebno.
                          </li>
                          <li>
                            Nositelji se raspoređuju tako da se ne susretnu u
                            ranim fazama (1. nositelj na vrhu, 2. na dnu
                            ždrijeba).
                          </li>
                          <li>
                            Pobjednici svake utakmice napreduju u sljedeću rundu
                            dok se ne dobije pobjednik turnira.
                          </li>
                        </ol>
                      </div>

                      <div className="flex justify-center p-4">
                        <svg width="400" height="300" viewBox="0 0 400 300">
                          {/* Round 1 */}
                          <rect
                            x="20"
                            y="40"
                            width="80"
                            height="30"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="20"
                            y="90"
                            width="80"
                            height="30"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="20"
                            y="180"
                            width="80"
                            height="30"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="20"
                            y="230"
                            width="80"
                            height="30"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <text
                            x="60"
                            y="60"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="12"
                          >
                            Team 1
                          </text>
                          <text
                            x="60"
                            y="110"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="12"
                          >
                            Team 2
                          </text>
                          <text
                            x="60"
                            y="200"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="12"
                          >
                            Team 3
                          </text>
                          <text
                            x="60"
                            y="250"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="12"
                          >
                            Team 4
                          </text>

                          {/* Connections to Round 2 */}
                          <line
                            x1="100"
                            y1="55"
                            x2="130"
                            y2="55"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="100"
                            y1="105"
                            x2="130"
                            y2="105"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="130"
                            y1="55"
                            x2="130"
                            y2="105"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="130"
                            y1="80"
                            x2="160"
                            y2="80"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <line
                            x1="100"
                            y1="195"
                            x2="130"
                            y2="195"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="100"
                            y1="245"
                            x2="130"
                            y2="245"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="130"
                            y1="195"
                            x2="130"
                            y2="245"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="130"
                            y1="220"
                            x2="160"
                            y2="220"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          {/* Round 2 */}
                          <rect
                            x="160"
                            y="65"
                            width="80"
                            height="30"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="160"
                            y="205"
                            width="80"
                            height="30"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <text
                            x="200"
                            y="80"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="12"
                          >
                            Semifinal 1
                          </text>
                          <text
                            x="200"
                            y="220"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="12"
                          >
                            Semifinal 2
                          </text>

                          {/* Connections to Final */}
                          <line
                            x1="240"
                            y1="80"
                            x2="270"
                            y2="80"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="240"
                            y1="220"
                            x2="270"
                            y2="220"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="270"
                            y1="80"
                            x2="270"
                            y2="220"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="270"
                            y1="150"
                            x2="300"
                            y2="150"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          {/* Final */}
                          <rect
                            x="300"
                            y="135"
                            width="80"
                            height="30"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <text
                            x="340"
                            y="150"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="12"
                          >
                            Final
                          </text>

                          {/* Labels */}
                          <text
                            x="60"
                            y="20"
                            textAnchor="middle"
                            fontSize="10"
                            fontWeight="bold"
                          >
                            Round 1
                          </text>
                          <text
                            x="200"
                            y="20"
                            textAnchor="middle"
                            fontSize="10"
                            fontWeight="bold"
                          >
                            Semifinals
                          </text>
                          <text
                            x="340"
                            y="20"
                            textAnchor="middle"
                            fontSize="10"
                            fontWeight="bold"
                          >
                            Final
                          </text>
                        </svg>
                      </div>
                    </div>
                  )}

                  {format === "DOUBLE_ELIMINATION" && (
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="bg-primary/10 p-3 rounded-full">
                          <Info className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium">
                            Dvostruko ispadanje (Double Elimination)
                          </h3>
                          <p className="text-muted-foreground mt-1">
                            U formatu s dvostrukim ispadanjem, ekipa mora
                            izgubiti dvije utakmice prije nego što ispadne iz
                            turnira. Ovaj format je pravedniji od jednostrukog
                            ispadanja jer daje ekipama drugu priliku.
                          </p>
                        </div>
                      </div>

                      <div className="bg-muted/30 p-4 rounded-lg">
                        <h4 className="font-medium mb-2">
                          Kako se generira ždrijeb:
                        </h4>
                        <ol className="list-decimal list-inside space-y-2 text-sm">
                          <li>
                            Turnir se sastoji od dva ždrijeba: gornji ždrijeb
                            (winners bracket) i donji ždrijeb (losers bracket).
                          </li>
                          <li>
                            Sve ekipe počinju u gornjem ždrijebu, koji
                            funkcionira kao turnir s jednim ispadanjem.
                          </li>
                          <li>
                            Ekipe koje izgube u gornjem ždrijebu prelaze u donji
                            ždrijeb gdje dobivaju drugu priliku.
                          </li>
                          <li>
                            Pobjednik gornjeg ždrijeba i pobjednik donjeg
                            ždrijeba igraju u finalu za ukupnog pobjednika.
                          </li>
                        </ol>
                      </div>

                      <div className="flex justify-center p-4">
                        <svg width="400" height="400" viewBox="0 0 400 400">
                          {/* Winners Bracket */}
                          <text
                            x="200"
                            y="20"
                            textAnchor="middle"
                            fontSize="14"
                            fontWeight="bold"
                          >
                            Gornji ždrijeb (Winners Bracket)
                          </text>

                          {/* Round 1 - Winners */}
                          <rect
                            x="20"
                            y="40"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="20"
                            y="75"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="20"
                            y="110"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="20"
                            y="145"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <text
                            x="60"
                            y="55"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Team 1
                          </text>
                          <text
                            x="60"
                            y="90"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Team 2
                          </text>
                          <text
                            x="60"
                            y="125"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Team 3
                          </text>
                          <text
                            x="60"
                            y="160"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Team 4
                          </text>

                          {/* Round 2 - Winners */}
                          <line
                            x1="100"
                            y1="52.5"
                            x2="120"
                            y2="52.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="100"
                            y1="87.5"
                            x2="120"
                            y2="87.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="120"
                            y1="52.5"
                            x2="120"
                            y2="87.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="120"
                            y1="70"
                            x2="140"
                            y2="70"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <line
                            x1="100"
                            y1="127.5"
                            x2="120"
                            y2="127.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="100"
                            y1="157.5"
                            x2="120"
                            y2="157.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="120"
                            y1="127.5"
                            x2="120"
                            y2="157.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="120"
                            y1="142.5"
                            x2="140"
                            y2="142.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <rect
                            x="140"
                            y="57.5"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="140"
                            y="130"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <text
                            x="180"
                            y="70"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Winner 1
                          </text>
                          <text
                            x="180"
                            y="142.5"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Winner 2
                          </text>

                          {/* Winners Final */}
                          <line
                            x1="220"
                            y1="70"
                            x2="240"
                            y2="70"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="220"
                            y1="142.5"
                            x2="240"
                            y2="142.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="240"
                            y1="70"
                            x2="240"
                            y2="142.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="240"
                            y1="106.25"
                            x2="260"
                            y2="106.25"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <rect
                            x="260"
                            y="93.75"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <text
                            x="300"
                            y="106.25"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Winners Final
                          </text>

                          {/* Losers Bracket */}
                          <text
                            x="200"
                            y="200"
                            textAnchor="middle"
                            fontSize="14"
                            fontWeight="bold"
                          >
                            Donji ždrijeb (Losers Bracket)
                          </text>

                          {/* Round 1 - Losers */}
                          <rect
                            x="20"
                            y="230"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <rect
                            x="20"
                            y="265"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <text
                            x="60"
                            y="242.5"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Loser W1
                          </text>
                          <text
                            x="60"
                            y="277.5"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Loser W2
                          </text>

                          {/* Round 2 - Losers */}
                          <line
                            x1="100"
                            y1="242.5"
                            x2="120"
                            y2="242.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="100"
                            y1="277.5"
                            x2="120"
                            y2="277.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="120"
                            y1="242.5"
                            x2="120"
                            y2="277.5"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="120"
                            y1="260"
                            x2="140"
                            y2="260"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <rect
                            x="140"
                            y="247.5"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <text
                            x="180"
                            y="260"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Losers Final
                          </text>

                          {/* Grand Final */}
                          <line
                            x1="300"
                            y1="118.75"
                            x2="300"
                            y2="320"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="220"
                            y1="260"
                            x2="240"
                            y2="260"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="240"
                            y1="260"
                            x2="240"
                            y2="320"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <line
                            x1="240"
                            y1="320"
                            x2="260"
                            y2="320"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />

                          <rect
                            x="260"
                            y="307.5"
                            width="80"
                            height="25"
                            rx="4"
                            fill="#fff"
                            stroke="#d1d5db"
                            strokeWidth="1.5"
                          />
                          <text
                            x="300"
                            y="320"
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                          >
                            Grand Final
                          </text>
                        </svg>
                      </div>
                    </div>
                  )}

                  {format === "GROUP_KNOCKOUT" && (
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="bg-primary/10 p-3 rounded-full">
                          <Info className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-lg font-medium">
                            Grupe + nokaut faza
                          </h3>
                          <p className="text-muted-foreground mt-1">
                            Ovaj format kombinira grupnu fazu (svatko sa svakim
                            unutar grupe) s nokaut fazom za najbolje ekipe iz
                            svake grupe. Ovaj format je popularan jer osigurava
                            više utakmica za sve ekipe i dramatičnu nokaut fazu.
                          </p>
                        </div>
                      </div>

                      <div className="bg-muted/30 p-4 rounded-lg">
                        <h4 className="font-medium mb-2">
                          Kako se generira ždrijeb:
                        </h4>
                        <ol className="list-decimal list-inside space-y-2 text-sm">
                          <li>
                            Ekipe se raspoređuju u grupe (najčešće 4 ekipe po
                            grupi).
                          </li>
                          <li>
                            Unutar svake grupe, ekipe igraju svatko sa svakim
                            (round-robin format).
                          </li>
                          <li>
                            Najbolje plasirane ekipe iz svake grupe (obično 2)
                            napreduju u nokaut fazu.
                          </li>
                          <li>
                            Nokaut faza se igra kao turnir s jednim ispadanjem,
                            gdje pobjednici napreduju do finala.
                          </li>
                        </ol>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <div className="bg-white p-4 rounded-lg border">
                          <h4 className="font-medium mb-2">Primjer grupa:</h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div className="bg-muted/30 p-2 rounded">
                              <div className="font-medium">Grupa A</div>
                              <div>Ekipa 1</div>
                              <div>Ekipa 2</div>
                              <div>Ekipa 3</div>
                              <div>Ekipa 4</div>
                            </div>
                            <div className="bg-muted/30 p-2 rounded">
                              <div className="font-medium">Grupa B</div>
                              <div>Ekipa 5</div>
                              <div>Ekipa 6</div>
                              <div>Ekipa 7</div>
                              <div>Ekipa 8</div>
                            </div>
                          </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg border">
                          <h4 className="font-medium mb-2">Nokaut faza:</h4>
                          <div className="text-sm space-y-1">
                            <div>Polufinale 1: A1 vs B2</div>
                            <div>Polufinale 2: B1 vs A2</div>
                            <div className="mt-2">
                              Finale: Pobjednik PF1 vs Pobjednik PF2
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <div className="flex justify-between items-center">
        <div className="text-sm text-muted-foreground">
          Minimalni broj ekipa:{" "}
          <span className="font-medium">{getMinimumTeamsRequired()}</span>
        </div>
        <Badge
          variant={
            selectedTeams.length >= getMinimumTeamsRequired()
              ? "default"
              : "destructive"
          }
        >
          {selectedTeams.length} ekipa odabrano
        </Badge>
      </div>
    </div>
  );
}
