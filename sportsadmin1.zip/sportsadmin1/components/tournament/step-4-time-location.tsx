"use client"

import { useState } from "react"
import { format } from "date-fns"
import { hr } from "date-fns/locale"
import { CalendarIcon, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"
import { venueOptions } from "@/lib/tournament-data"
import Image from "next/image"

interface Step4Props {
  startDate: Date
  endDate: Date
  venue: string
  onStartDateChange: (date: Date) => void
  onEndDateChange: (date: Date) => void
  onVenueChange: (venue: string) => void
}

export function Step4TimeLocation({
  startDate,
  endDate,
  venue,
  onStartDateChange,
  onEndDateChange,
  onVenueChange,
}: Step4Props) {
  const [calendarView, setCalendarView] = useState<"start" | "end">("start")
  const selectedVenue = venueOptions.find((v) => v.id === venue)

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold mb-2">Vrijeme i lokacija</h2>
        <p className="text-muted-foreground">Odaberite datum početka i završetka turnira, te lokaciju održavanja.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Datumi turnira</CardTitle>
            <CardDescription>Odaberite datum početka i završetka turnira</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="font-medium text-sm">Datum početka</div>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !startDate && "text-muted-foreground",
                      )}
                      onClick={() => setCalendarView("start")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {startDate ? format(startDate, "PPP", { locale: hr }) : "Odaberi datum"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={startDate}
                      onSelect={(date) => date && onStartDateChange(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <div className="font-medium text-sm">Datum završetka</div>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !endDate && "text-muted-foreground")}
                      onClick={() => setCalendarView("end")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {endDate ? format(endDate, "PPP", { locale: hr }) : "Odaberi datum"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={endDate}
                      onSelect={(date) => date && onEndDateChange(date)}
                      initialFocus
                      fromDate={startDate}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div className="pt-4">
              <div className="text-sm text-muted-foreground">
                Trajanje turnira:{" "}
                {startDate && endDate
                  ? `${Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))} dana`
                  : "Odaberite datume"}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Lokacija</CardTitle>
            <CardDescription>Odaberite lokaciju održavanja turnira</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={venue} onValueChange={onVenueChange}>
              <SelectTrigger>
                <SelectValue placeholder="Odaberite lokaciju" />
              </SelectTrigger>
              <SelectContent>
                {venueOptions.map((venue) => (
                  <SelectItem key={venue.id} value={venue.id}>
                    {venue.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {selectedVenue && (
              <div className="pt-4 space-y-2">
                <div className="flex items-center text-sm">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{selectedVenue.address}</span>
                </div>
                <div className="rounded-md overflow-hidden border h-[200px] relative">
                  <Image src="/zagreb-city-map.png" alt="Map location" fill className="object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-primary h-4 w-4 rounded-full animate-pulse" />
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
