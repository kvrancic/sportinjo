"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { type Competitor, getCompetitorById } from "@/lib/data";
import {
  type TournamentFormat,
  type TournamentMatch,
  venueOptions,
} from "@/lib/tournament-data";
import { format as formatDate } from "date-fns"; // Renamed to formatDate to avoid conflict
import { hr } from "date-fns/locale";
import {
  Calendar,
  Clock,
  Download,
  MapPin,
  Shuffle,
  ArrowLeftRight,
  Edit,
  Trash2,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import Image from "next/image";
import { getTeamLogo } from "@/lib/team-logos";
import KnockoutBracket from "./knockout-bracket";

interface Step5Props {
  format: TournamentFormat;
  matches: TournamentMatch[];
  competitors: Competitor[];
  onMatchesChange: (matches: TournamentMatch[]) => void;
}

export function Step5Schedule({
  format,
  matches,
  competitors,
  onMatchesChange,
}: Step5Props) {
  const [activeTab, setActiveTab] = useState("list");
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [currentMatch, setCurrentMatch] = useState<TournamentMatch | null>(
    null
  );
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [time, setTime] = useState("12:00");
  const [venue, setVenue] = useState("");

  // Handle match edit
  const handleEditMatch = (match: TournamentMatch) => {
    setCurrentMatch(match);
    const matchDate = new Date(match.date);
    setDate(matchDate);
    setTime(formatDate(matchDate, "HH:mm")); // Using renamed formatDate
    setVenue(match.venue);
    setEditDialogOpen(true);
  };

  // Handle match delete
  const handleDeleteMatch = (id: string) => {
    const updatedMatches = matches.filter((m) => m.id !== id);
    onMatchesChange(updatedMatches);
  };

  // Save match changes
  const saveMatchChanges = () => {
    if (!currentMatch || !date) return;

    const [hours, minutes] = time.split(":").map(Number);
    const newDate = new Date(date);
    newDate.setHours(hours, minutes, 0);

    const updatedMatches = matches.map((match) => {
      if (match.id === currentMatch.id) {
        return {
          ...match,
          date: newDate.toISOString(),
          venue,
        };
      }
      return match;
    });

    onMatchesChange(updatedMatches);
    setEditDialogOpen(false);
  };

  // Utility functions for match manipulation
  const handleRandomizeTimes = () => {
    const updatedMatches = [...matches];

    // Get the first and last match dates
    if (matches.length === 0) return;

    const firstMatchDate = new Date(
      Math.min(...matches.map((m) => new Date(m.date).getTime()))
    );
    const lastMatchDate = new Date(
      Math.max(...matches.map((m) => new Date(m.date).getTime()))
    );

    // Calculate the number of days between
    const daysBetween = Math.ceil(
      (lastMatchDate.getTime() - firstMatchDate.getTime()) /
        (1000 * 60 * 60 * 24)
    );

    // Randomize times for each match
    updatedMatches.forEach((match) => {
      // Random day within the tournament period
      const randomDayOffset = Math.floor(Math.random() * (daysBetween + 1));
      const randomDate = new Date(firstMatchDate);
      randomDate.setDate(firstMatchDate.getDate() + randomDayOffset);

      // Random hour between 10:00 and 20:00
      const randomHour = 10 + Math.floor(Math.random() * 11);
      // Random minute (0, 15, 30, 45)
      const randomMinute = Math.floor(Math.random() * 4) * 15;

      randomDate.setHours(randomHour, randomMinute, 0);
      match.date = randomDate.toISOString();
    });

    onMatchesChange(updatedMatches);
  };

  const handleBalanceHomeAway = () => {
    const updatedMatches = [...matches];

    // Count home matches for each team
    const homeMatchCounts: Record<string, number> = {};

    matches.forEach((match) => {
      if (!homeMatchCounts[match.homeCompetitorId]) {
        homeMatchCounts[match.homeCompetitorId] = 0;
      }
      homeMatchCounts[match.homeCompetitorId]++;
    });

    // Find teams with imbalanced home/away matches
    const teamsToBalance = Object.entries(homeMatchCounts)
      .filter(([teamId, count]) => {
        const awayCount = matches.filter(
          (m) => m.awayCompetitorId === teamId
        ).length;
        return Math.abs(count - awayCount) > 1;
      })
      .sort(([, countA], [, countB]) => countB - countA) // Sort by most home matches
      .map(([teamId]) => teamId);

    // Swap some matches to balance
    for (const teamId of teamsToBalance) {
      const homeMatches = updatedMatches.filter(
        (m) => m.homeCompetitorId === teamId
      );
      const awayMatches = updatedMatches.filter(
        (m) => m.awayCompetitorId === teamId
      );

      if (homeMatches.length > awayMatches.length + 1) {
        // Need to swap some home matches to away
        const matchesToSwap = homeMatches.slice(
          0,
          homeMatches.length - awayMatches.length - 1
        );

        matchesToSwap.forEach((match) => {
          // Swap home and away
          const temp = match.homeCompetitorId;
          match.homeCompetitorId = match.awayCompetitorId;
          match.awayCompetitorId = temp;
        });
      }
    }

    onMatchesChange(updatedMatches);
  };

  const handleExportCsv = () => {
    // Create CSV content
    let csvContent = "Runda,Datum,Vrijeme,Domaćin,Gost,Lokacija\n";

    matches.forEach((match) => {
      const homeTeam = getCompetitorById(match.homeCompetitorId)?.name || "TBD";
      const awayTeam = getCompetitorById(match.awayCompetitorId)?.name || "TBD";
      const matchDate = new Date(match.date);
      const dateStr = formatDate(matchDate, "dd.MM.yyyy"); // Using renamed formatDate
      const timeStr = formatDate(matchDate, "HH:mm"); // Using renamed formatDate
      const venueStr =
        venueOptions.find((v) => v.id === match.venue)?.name || "Nije određeno";

      csvContent += `${match.round},${dateStr},${timeStr},${homeTeam},${awayTeam},${venueStr}\n`;
    });

    // Create a download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "raspored_turnira.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Raspored</h2>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRandomizeTimes}
            className="text-xs flex items-center gap-1"
          >
            <Shuffle className="h-3 w-3" />
            Nasumično vrijeme
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleBalanceHomeAway}
            className="text-xs flex items-center gap-1"
          >
            <ArrowLeftRight className="h-3 w-3" />
            Balansiraj domaćinstva
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            className="text-xs flex items-center gap-1"
          >
            <Download className="h-3 w-3" />
            CSV Export
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="list">Lista utakmica</TabsTrigger>
              <TabsTrigger value="bracket">Vizualizacija</TabsTrigger>
            </TabsList>
            <TabsContent value="list" className="pt-4">
              {matches.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nema utakmica za prikaz. Utakmice će biti generirane nakon što
                  završite kreiranje turnira.
                </div>
              ) : (
                <div className="space-y-4">
                  {matches.map((match) => (
                    <Card key={match.id} className="overflow-hidden">
                      <div className="flex items-center justify-between p-4">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2">
                            <div className="h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                              <Image
                                src={
                                  getTeamLogo(match.homeCompetitorId) ||
                                  "/placeholder.svg"
                                }
                                alt={
                                  getCompetitorById(match.homeCompetitorId)
                                    ?.name || ""
                                }
                                width={40}
                                height={40}
                                className="object-cover"
                              />
                            </div>
                            <span className="font-medium">
                              {getCompetitorById(match.homeCompetitorId)
                                ?.name || "TBD"}
                            </span>
                          </div>

                          <div className="flex flex-col items-center">
                            <span className="text-sm font-medium">vs</span>
                            {match.result && (
                              <span className="text-xs bg-muted px-2 py-0.5 rounded-full mt-1">
                                {match.result.homeScore} -{" "}
                                {match.result.awayScore}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2">
                            <div className="h-10 w-10 rounded-full overflow-hidden bg-muted flex items-center justify-center border-2 border-white shadow-sm">
                              <Image
                                src={
                                  getTeamLogo(match.awayCompetitorId) ||
                                  "/placeholder.svg"
                                }
                                alt={
                                  getCompetitorById(match.awayCompetitorId)
                                    ?.name || ""
                                }
                                width={40}
                                height={40}
                                className="object-cover"
                              />
                            </div>
                            <span className="font-medium">
                              {getCompetitorById(match.awayCompetitorId)
                                ?.name || "TBD"}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="flex flex-col items-end">
                            <div className="flex items-center gap-1 text-sm">
                              <Calendar className="h-3 w-3 text-muted-foreground" />
                              <span>
                                {formatDate(new Date(match.date), "dd.MM.yyyy")}
                              </span>{" "}
                              {/* Using renamed formatDate */}
                            </div>
                            <div className="flex items-center gap-1 text-sm mt-1">
                              <Clock className="h-3 w-3 text-muted-foreground" />
                              <span>
                                {formatDate(new Date(match.date), "HH:mm")}
                              </span>{" "}
                              {/* Using renamed formatDate */}
                            </div>
                            <div className="flex items-center gap-1 text-sm mt-1">
                              <MapPin className="h-3 w-3 text-muted-foreground" />
                              <span>
                                {venueOptions.find((v) => v.id === match.venue)
                                  ?.name || "Nije određeno"}
                              </span>
                            </div>
                          </div>

                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleEditMatch(match)}
                              className="h-8 w-8"
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Uredi utakmicu</span>
                            </Button>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => handleDeleteMatch(match.id)}
                              className="h-8 w-8 text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Obriši utakmicu</span>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
            <TabsContent value="bracket" className="pt-4">
              {format === "SINGLE_ELIMINATION" ||
              format === "DOUBLE_ELIMINATION" ? (
                <KnockoutBracket
                  matches={matches}
                  competitors={competitors}
                  onEdit={handleEditMatch}
                  onDelete={handleDeleteMatch}
                  openEditDialog={setEditDialogOpen}
                />
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  Vizualizacija nokaut faze dostupna je samo za turnire s
                  eliminacijskim formatom.
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Edit Match Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Uredi utakmicu</DialogTitle>
            <DialogDescription>
              Promijeni datum, vrijeme i lokaciju utakmice.
            </DialogDescription>
          </DialogHeader>

          {currentMatch && (
            <div className="grid gap-4 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                    <Image
                      src={
                        getTeamLogo(currentMatch.homeCompetitorId) || "/tbd.png"
                      }
                      alt={
                        getCompetitorById(currentMatch.homeCompetitorId)
                          ?.name || ""
                      }
                      width={32}
                      height={32}
                      className="object-cover"
                    />
                  </div>
                  <span>
                    {getCompetitorById(currentMatch.homeCompetitorId)?.name ||
                      "TBD"}
                  </span>
                </div>
                <span className="font-bold">vs</span>
                <div className="flex items-center gap-2">
                  <span>
                    {getCompetitorById(currentMatch.awayCompetitorId)?.name ||
                      "TBD"}
                  </span>
                  <div className="h-8 w-8 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                    <Image
                      src={
                        getTeamLogo(currentMatch.awayCompetitorId) || "/tbd.png"
                      }
                      alt={
                        getCompetitorById(currentMatch.awayCompetitorId)
                          ?.name || ""
                      }
                      width={32}
                      height={32}
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Datum</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !date && "text-muted-foreground"
                        )}
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {date ? (
                          formatDate(date, "PPP", { locale: hr })
                        ) : (
                          <span>Odaberi datum</span>
                        )}{" "}
                        {/* Using renamed formatDate */}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={date}
                        onSelect={setDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time">Vrijeme</Label>
                  <Input
                    id="time"
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="venue">Lokacija</Label>
                <Select value={venue} onValueChange={setVenue}>
                  <SelectTrigger>
                    <SelectValue placeholder="Odaberi lokaciju" />
                  </SelectTrigger>
                  <SelectContent>
                    {venueOptions.map((v) => (
                      <SelectItem key={v.id} value={v.id}>
                        {v.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              Odustani
            </Button>
            <Button onClick={saveMatchChanges}>Spremi promjene</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
