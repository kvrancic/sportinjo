"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, MapPin, Trophy, Clock, Edit, Save, FileText } from "lucide-react"
import { type TournamentFormat, formatDisplayNames, venueOptions } from "@/lib/tournament-data"
import { type Category, type Competitor, getCategoryById, getCompetitorById } from "@/lib/data"
import { CategoryBadge } from "@/components/category-badge"
import Image from "next/image"
import { getTeamLogo } from "@/lib/team-logos"
import { motion } from "framer-motion"
import confetti from "canvas-confetti"

interface Step6Props {
  name: string
  format: TournamentFormat
  categoryIds: string[]
  competitorIds: string[]
  startDate: Date
  endDate: Date
  venue: string
  onEditStep: (step: number) => void
  onSave: (isDraft: boolean) => void
  categories: Category[]
  competitors: Competitor[]
}

export function Step6Review({
  name,
  format,
  categoryIds,
  competitorIds,
  startDate,
  endDate,
  venue,
  onEditStep,
  onSave,
  categories,
  competitors,
}: Step6Props) {
  const selectedCategories = categoryIds.map((id) => getCategoryById(id)).filter(Boolean) as Category[]
  const selectedCompetitors = competitorIds.map((id) => getCompetitorById(id)).filter(Boolean) as Competitor[]
  const selectedVenue = venueOptions.find((v) => v.id === venue)

  const handleSaveAndStart = () => {
    // Trigger confetti effect
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    })

    onSave(false)
  }

  const handleSaveAsDraft = () => {
    onSave(true)
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="w-full lg:w-1/2 space-y-6">
          <h2 className="text-2xl font-bold">Pregled i potvrda</h2>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center justify-between">
                <span>Osnovne informacije</span>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => onEditStep(0)}>
                  <Edit className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg">{name}</h3>
                <Badge variant="outline" className="mt-1">
                  {formatDisplayNames[format]}
                </Badge>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <Trophy className="h-4 w-4 text-amber-600" />
                <span>Format: {formatDisplayNames[format]}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center justify-between">
                <span>Kategorije</span>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => onEditStep(1)}>
                  <Edit className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {selectedCategories.length > 0 ? (
                  selectedCategories.map((category) => (
                    <CategoryBadge
                      key={category.id}
                      name={category.name}
                      gender={category.gender}
                      ageGroup={category.ageGroup}
                    />
                  ))
                ) : (
                  <span className="text-sm text-muted-foreground">Nema odabranih kategorija</span>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center justify-between">
                <span>Natjecatelji</span>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => onEditStep(2)}>
                  <Edit className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                {selectedCompetitors.length > 0 ? (
                  selectedCompetitors.map((competitor) => (
                    <div
                      key={competitor.id}
                      className="flex items-center gap-2 bg-muted/30 rounded-full pl-1 pr-3 py-1"
                    >
                      <div className="h-6 w-6 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                        <Image
                          src={getTeamLogo(competitor.id) || "/placeholder.svg"}
                          alt={competitor.name}
                          width={24}
                          height={24}
                          className="object-cover"
                        />
                      </div>
                      <span className="text-sm font-medium">{competitor.name}</span>
                    </div>
                  ))
                ) : (
                  <span className="text-sm text-muted-foreground">Nema odabranih natjecatelja</span>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center justify-between">
                <span>Vrijeme i lokacija</span>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => onEditStep(3)}>
                  <Edit className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2 text-sm">
                <CalendarIcon className="h-4 w-4 text-blue-600" />
                <span>Početak: {startDate ? startDate.toLocaleDateString("hr-HR") : "Nije određeno"}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CalendarIcon className="h-4 w-4 text-blue-600" />
                <span>Završetak: {endDate ? endDate.toLocaleDateString("hr-HR") : "Nije određeno"}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Clock className="h-4 w-4 text-blue-600" />
                <span>
                  Trajanje:{" "}
                  {startDate && endDate
                    ? Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
                    : 0}{" "}
                  dana
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-rose-600" />
                <span>Lokacija: {selectedVenue?.name || "Nije određeno"}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center justify-between">
                <span>Raspored</span>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => onEditStep(4)}>
                  <Edit className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Raspored utakmica</span>
                </div>
                <Button variant="outline" size="sm" className="h-7 text-xs">
                  Pregledaj
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="w-full lg:w-1/2 space-y-6">
          <h2 className="text-2xl font-bold">Pregled</h2>

          {format === "ROUND_ROBIN" ? (
            <Card>
              <CardHeader>
                <CardTitle>Pregled lige</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-3 text-sm font-medium">Pozicija</th>
                        <th className="text-left p-3 text-sm font-medium">Ekipa</th>
                        <th className="text-center p-3 text-sm font-medium">O</th>
                        <th className="text-center p-3 text-sm font-medium">P</th>
                        <th className="text-center p-3 text-sm font-medium">N</th>
                        <th className="text-center p-3 text-sm font-medium">I</th>
                        <th className="text-center p-3 text-sm font-medium">Bodovi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {selectedCompetitors.slice(0, 5).map((competitor, index) => (
                        <tr key={competitor.id} className="hover:bg-muted/30 transition-colors">
                          <td className="p-3 text-center">{index + 1}</td>
                          <td className="p-3">
                            <div className="flex items-center gap-2">
                              <div className="h-6 w-6 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                                <Image
                                  src={getTeamLogo(competitor.id) || "/placeholder.svg"}
                                  alt={competitor.name}
                                  width={24}
                                  height={24}
                                  className="object-cover"
                                />
                              </div>
                              <span className="text-sm font-medium">{competitor.name}</span>
                            </div>
                          </td>
                          <td className="p-3 text-center">0</td>
                          <td className="p-3 text-center">0</td>
                          <td className="p-3 text-center">0</td>
                          <td className="p-3 text-center">0</td>
                          <td className="p-3 text-center">0</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Pregled ždrijeba</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center p-4">
                  <div className="bracket-preview">
                    <svg width="400" height="200" viewBox="0 0 400 200">
                      {/* First round */}
                      <line x1="80" y1="40" x2="120" y2="40" stroke="#d1d5db" strokeWidth="2" />
                      <line x1="80" y1="80" x2="120" y2="80" stroke="#d1d5db" strokeWidth="2" />
                      <line x1="120" y1="40" x2="120" y2="80" stroke="#d1d5db" strokeWidth="2" />
                      <line x1="120" y1="60" x2="160" y2="60" stroke="#d1d5db" strokeWidth="2" />

                      <line x1="80" y1="120" x2="120" y2="120" stroke="#d1d5db" strokeWidth="2" />
                      <line x1="80" y1="160" x2="120" y2="160" stroke="#d1d5db" strokeWidth="2" />
                      <line x1="120" y1="120" x2="120" y2="160" stroke="#d1d5db" strokeWidth="2" />
                      <line x1="120" y1="140" x2="160" y2="140" stroke="#d1d5db" strokeWidth="2" />

                      {/* Final */}
                      <line x1="160" y1="60" x2="160" y2="140" stroke="#d1d5db" strokeWidth="2" />
                      <line x1="160" y1="100" x2="200" y2="100" stroke="#d1d5db" strokeWidth="2" />

                      {/* Team slots */}
                      {selectedCompetitors.slice(0, 4).map((competitor, index) => {
                        const y = index < 2 ? 40 + index * 40 : 120 + (index - 2) * 40

                        return (
                          <g key={competitor.id}>
                            <rect
                              x="20"
                              y={y - 10}
                              width="60"
                              height="20"
                              rx="4"
                              fill="#fff"
                              stroke="#d1d5db"
                              strokeWidth="1"
                            />
                            <image
                              href={getTeamLogo(competitor.id) || "/placeholder.svg"}
                              x="25"
                              y={y - 5}
                              height="10"
                              width="10"
                            />
                            <text x="40" y={y + 3} fontSize="8" textAnchor="start">
                              {competitor.name}
                            </text>
                          </g>
                        )
                      })}

                      {/* Final slot */}
                      <rect x="200" y="90" width="60" height="20" rx="4" fill="#fff" stroke="#d1d5db" strokeWidth="1" />
                      <text x="230" y="103" fontSize="8" textAnchor="middle">
                        Pobjednik
                      </text>
                    </svg>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-4">
            <motion.div
              className="flex flex-col gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Button size="lg" className="bg-amber-600 hover:bg-amber-700 h-14 text-base" onClick={handleSaveAndStart}>
                <Save className="mr-2 h-5 w-5" />
                Spremi i pokreni turnir
              </Button>

              <Button variant="outline" size="lg" className="h-12" onClick={handleSaveAsDraft}>
                <FileText className="mr-2 h-5 w-5" />
                Spremi kao skicu
              </Button>
            </motion.div>

            <div className="rounded-lg bg-amber-50 border border-amber-200 p-4">
              <h3 className="font-semibold text-amber-800 mb-2">Napomena</h3>
              <p className="text-sm text-amber-700">
                Provjerite sve detalje prije spremanja. Nakon što pokrenete turnir, neki detalji se više neće moći
                mijenjati.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
