"use client"

import { useState, useEffect, type ReactNode } from "react"
import { Button } from "@/components/ui/button"
import { WizardStepper, type Step } from "@/components/tournament/wizard-stepper"
import { useRouter } from "next/navigation"
import { ChevronLeft, ChevronRight, Save, X } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface WizardLayoutProps {
  children: ReactNode
  steps: Step[]
  currentStep: number
  completedSteps: number[]
  isNextDisabled: boolean
  onNext: () => void
  onBack: () => void
  confederationId: string
}

export function WizardLayout({
  children,
  steps,
  currentStep,
  completedSteps,
  isNextDisabled,
  onNext,
  onBack,
  confederationId,
}: WizardLayoutProps) {
  const router = useRouter()
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [scrollPosition, setScrollPosition] = useState(0)
  const isLastStep = currentStep === steps.length - 1

  // Track scroll position for visual effects
  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Handle escape key to show exit dialog
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowConfirmation(true)
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  const handleExit = () => {
    router.push(`/confederations/${confederationId}/turniri`)
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header with stepper - always visible */}
      <header
        className={`sticky top-0 z-30 w-full border-b bg-background transition-all duration-200 ${
          scrollPosition > 10 ? "shadow-md" : ""
        }`}
      >
        <div className="container mx-auto py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-bold">Novi turnir</h1>
            <Button variant="ghost" size="icon" onClick={() => setShowConfirmation(true)} aria-label="Odustani">
              <X className="h-5 w-5" />
            </Button>
          </div>
          <WizardStepper steps={steps} currentStep={currentStep} completedSteps={completedSteps} />
        </div>
      </header>

      {/* Main content area with proper spacing */}
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-6xl mx-auto">{children}</div>
      </main>

      {/* Footer with navigation buttons - always visible */}
      <footer className="sticky bottom-0 z-30 w-full border-t bg-background py-4 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={onBack} disabled={currentStep === 0} className="flex items-center gap-2">
              <ChevronLeft className="h-4 w-4" />
              <span>Nazad</span>
            </Button>

            <div className="text-sm text-muted-foreground">
              Korak {currentStep + 1} od {steps.length}
            </div>

            <Button onClick={onNext} disabled={isNextDisabled} className="flex items-center gap-2">
              {isLastStep ? (
                <>
                  <Save className="h-4 w-4" />
                  <span>Spremi i pokreni</span>
                </>
              ) : (
                <>
                  <span>Nastavi</span>
                  <ChevronRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </div>
      </footer>

      {/* Exit confirmation dialog */}
      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Jeste li sigurni da želite odustati?</AlertDialogTitle>
            <AlertDialogDescription>
              Ako odustanete, izgubit ćete sve unesene podatke. Ova radnja se ne može poništiti.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Nastavi uređivanje</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleExit}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Odustani od kreiranja
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
