"use client"

import { cn } from "@/lib/utils"
import { Check } from "lucide-react"

export interface Step {
  id: string
  title: string
  description?: string
}

interface WizardStepperProps {
  steps: Step[]
  currentStep: number
  completedSteps: number[]
}

export function WizardStepper({ steps, currentStep, completedSteps }: WizardStepperProps) {
  return (
    <div className="w-full">
      <div className="hidden md:flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={step.id} className="flex flex-col items-center relative">
            {/* Connector line */}
            {index < steps.length - 1 && (
              <div
                className={cn(
                  "absolute top-5 left-[50%] w-full h-[2px]",
                  index < currentStep || completedSteps.includes(index) ? "bg-primary" : "bg-muted",
                )}
              />
            )}

            {/* Step circle */}
            <div
              className={cn(
                "z-10 flex items-center justify-center w-10 h-10 rounded-full border-2 transition-colors",
                index === currentStep
                  ? "border-primary bg-primary text-primary-foreground"
                  : index < currentStep || completedSteps.includes(index)
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-muted bg-background text-muted-foreground",
              )}
            >
              {completedSteps.includes(index) ? (
                <Check className="h-5 w-5" />
              ) : (
                <span className="text-sm font-medium">{index + 1}</span>
              )}
            </div>

            {/* Step title */}
            <div className="mt-2 text-center">
              <p
                className={cn(
                  "text-sm font-medium",
                  index === currentStep
                    ? "text-foreground"
                    : index < currentStep || completedSteps.includes(index)
                      ? "text-foreground"
                      : "text-muted-foreground",
                )}
              >
                {step.title}
              </p>
              {step.description && (
                <p className="text-xs text-muted-foreground mt-1 max-w-[120px]">{step.description}</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Mobile stepper - simplified version */}
      <div className="md:hidden flex items-center justify-between">
        <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
          <div
            className="bg-primary h-full transition-all duration-300 ease-in-out"
            style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>
    </div>
  )
}
