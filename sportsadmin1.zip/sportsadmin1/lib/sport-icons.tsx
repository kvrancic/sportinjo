import type React from "react";
import {
  FaFutbol,
  FaBasketballBall,
  FaVolleyballBall,
  FaSwimmer,
  FaSkiing,
  FaTableTennis,
  FaRunning,
  FaChessKnight,
  FaCarSide,
  FaPlane,
  FaWater,
  FaAnchor,
  FaBullseye,
  FaDumbbell,
  FaGolfBall,
  FaMountain,
} from "react-icons/fa";
import {
  GiTennisRacket,
  GiWaterPolo,
  GiBoatFishing,
  GiBowlingStrike,
  GiBoxingGlove,
  GiHockey,
  GiJumpingRope,
  GiRugbyConversion,
  GiScubaMask,
  GiCrossedSwords,
} from "react-icons/gi";
import { MdSportsHandball, MdSportsMartialArts } from "react-icons/md";

type SportIconComponent = React.ComponentType<React.SVGProps<SVGSVGElement>>;

type SportIconMap = {
  [key: string]: SportIconComponent;
};

export const sportIcons: SportIconMap = {
  Nogomet: FaFutbol,
  Rukomet: MdSportsHandball,
  Košarka: FaBasketballBall,
  Plivanje: FaSwimmer,
  Skijanje: FaSkiing,
  Tenis: GiTennisRacket,
  Vaterpolo: GiWaterPolo,
  Atletika: FaRunning,
  "Stolni tenis": FaTableTennis,
  Veslanje: GiBoatFishing,
  Odbojka: FaVolleyballBall,
  Taekwondo: MdSportsMartialArts,
  Karate: MdSportsMartialArts,
  Kuglanje: GiBowlingStrike,
  Kajakaštvo: FaAnchor,
  Ronjenje: GiScubaMask,
  "Ju-jitsu": GiCrossedSwords,
  Pikado: FaBullseye,
  Hrvanje: GiBoxingGlove,
  Judo: MdSportsMartialArts,
  Gimnastika: GiJumpingRope,
  Badminton: GiTennisRacket,
  Zrakoplovstvo: FaPlane,
  Automobilizam: FaCarSide,
  "Umjetničko plivanje": FaWater,
  "Hokej na travi": GiHockey,
  Šah: FaChessKnight,
  Ragbi: GiRugbyConversion,
  Golf: FaGolfBall,
  Planinarenje: FaMountain,
};

// Fallback icon for unknown sports
export const DefaultSportIcon = FaDumbbell;

export function getSportIcon(sport: string): SportIconComponent {
  return sportIcons[sport] || DefaultSportIcon;
}
