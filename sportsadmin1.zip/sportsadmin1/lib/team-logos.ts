// This file provides a mapping of team IDs to logo images
// Later this can be replaced with real team logos

type TeamLogoMap = {
  [key: string]: string;
};

// Placeholder logos for hockey teams
export const teamLogos: TeamLogoMap = {
  // Hockey teams
  comp_hk_jedinstvo:
    "/team-logos/4988ef_ceff3e62264b4637851dd5c5cbecb781~mv2.jpg",
  comp_hk_marathon: "/team-logos/agro.png",
  comp_hk_mladost_2: "/team-logos/default-logo.png",
  comp_hk_mladost: "/team-logos/DUBROVNIK_CURE_SMALL.png",
  comp_hk_concordia_1906: "/team-logos/eriscon.png",
  comp_hk_tresnjevka: "/team-logos/jedinstvo.png",
  comp_hk_zelina: "/team-logos/Mala_Mlaka.png",
  comp_hk_zrinjevac: "/team-logos/OKM_Centrometal.png",

  // Chess clubs
  comp_sk_sesvete: "/team-logos/OK_Dinamo.png",
  comp_sk_novi_zg: "/team-logos/OK_Kelteks.png",
  comp_sk_caissa: "/team-logos/OK_Rovinj.png",
  comp_sk_vrustun: "/team-logos/podsused.png",
  comp_sk_silent: "/team-logos/polet.png",
  comp_sk_podsused: "/team-logos/RK_Sinj.png",

  // Football clubs
  comp_nk_botinec: "/team-logos/RK_Zagreb.png",
  comp_nk_bubamara: "/team-logos/SK_Caissa.png",
  comp_nk_concordia: "/team-logos/SK_Koncar.png",
  comp_nk_devetka: "/team-logos/SK_Maksmimir.png",
  comp_nk_kralj_tomislav: "/team-logos/SK_Novi_Zagreb.png",
  comp_nk_brezovica: "/team-logos/team-logos/SK-Vrustun-football-match.png",
  comp_nk_hrvatski_leskovac: "/team-logos/team-logos/football-logo-7.png",
  comp_nk_kasina: "/team-logos/team-logos/football-logo-8.png",

  // Rugby clubs
  comp_rk_sinj: "/team-logos/team-logos/rugby-logo-1.png",
  comp_rk_nada: "/team-logos/team-logos/rugby-logo-2.png",
  comp_hark_mladost: "/team-logos/team-logos/rugby-logo-3.png",
  comp_rk_zagreb: "/team-logos/team-logos/rugby-logo-4.png",

  // Volleyball clubs
  comp_haok_mladost: "/team-logos/team-logos/volleyball-logo-1.png",
  comp_ok_dinamo: "/team-logos/team-logos/volleyball-logo-2.png",
  comp_ok_marina_kastela: "/team-logos/team-logos/volleyball-logo-3.png",
  comp_ok_split: "/team-logos/team-logos/volleyball-logo-4.png",
};

// Helper function to get a logo for a team ID
export function getTeamLogo(teamId: string): string {
  return teamLogos[teamId];
}
