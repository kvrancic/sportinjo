import { v4 as uuidv4 } from "uuid"

export type TournamentFormat = "ROUND_ROBIN" | "SINGLE_ELIMINATION" | "DOUBLE_ELIMINATION" | "GROUP_KNOCKOUT"

export interface Tournament {
  id: string
  name: string
  format: TournamentFormat
  categoryIds: string[]
  competitorIds: string[]
  startDate: string
  endDate: string
  venue: string
  matches: TournamentMatch[]
  status: "DRAFT" | "ACTIVE" | "COMPLETED" | "CANCELLED"
  confederationId: string
  createdAt: string
}

export interface TournamentMatch {
  id: string
  tournamentId: string
  round: number
  homeCompetitorId: string
  awayCompetitorId: string
  date: string
  venue: string
  result?: { homeScore: number; awayScore: number }
  status: "SCHEDULED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED"
  // For knockout tournaments
  matchNumber?: number
  nextMatchId?: string
  nextMatchPosition?: "home" | "away"
}

export const venueOptions = [
  {
    id: "venue-1",
    name: "Sportska dvorana Zagreb",
    address: "Trg Krešimira Ćosića 11, Zagreb",
    capacity: "5,000",
  },
  {
    id: "venue-2",
    name: "Dom sportova",
    address: "Trg Krešimira Ćosića 11, Zagreb",
    capacity: "3,000",
  },
  {
    id: "venue-3",
    name: "Arena Zagreb",
    address: "Lanište 30, Zagreb",
    capacity: "15,000",
  },
  {
    id: "venue-4",
    name: "Stadion Maksimir",
    address: "Maksimirska cesta 128, Zagreb",
    capacity: "35,000",
  },
]

// Sample tournament data
export const tournaments: Tournament[] = [
  {
    id: "tournament_1",
    name: "Prvenstvo Zagreba u hokeju na travi 2025",
    format: "ROUND_ROBIN",
    categoryIds: ["cat_ht_seniori"],
    competitorIds: [
      "comp_hk_jedinstvo",
      "comp_hk_marathon",
      "comp_hk_mladost",
      "comp_hk_concordia_1906",
      "comp_hk_tresnjevka",
      "comp_hk_zelina",
      "comp_hk_zrinjevac",
    ],
    startDate: "2025-03-01T00:00:00Z",
    endDate: "2025-06-15T00:00:00Z",
    venue: "Hokejski centar",
    matches: [],
    status: "ACTIVE",
    confederationId: "conf_hokej_na_travi_zg",
    createdAt: "2025-02-15T10:00:00Z",
  },
  {
    id: "tournament_2",
    name: "Kup grada Zagreba 2025",
    format: "SINGLE_ELIMINATION",
    categoryIds: ["cat_ht_seniori"],
    competitorIds: ["comp_hk_jedinstvo", "comp_hk_marathon", "comp_hk_mladost", "comp_hk_concordia_1906"],
    startDate: "2025-05-01T00:00:00Z",
    endDate: "2025-05-30T00:00:00Z",
    venue: "Sportski park Mladost",
    matches: [],
    status: "DRAFT",
    confederationId: "conf_hokej_na_travi_zg",
    createdAt: "2025-04-01T14:30:00Z",
  },
  {
    id: "tournament_3",
    name: "Juniorski turnir Zagreba",
    format: "GROUP_KNOCKOUT",
    categoryIds: ["cat_ht_kadeti"],
    competitorIds: [
      "comp_hk_jedinstvo",
      "comp_hk_mladost",
      "comp_hk_mladost_2",
      "comp_hk_concordia_1906",
      "comp_hk_tresnjevka",
      "comp_hk_zelina",
      "comp_hk_zrinjevac",
    ],
    startDate: "2025-07-01T00:00:00Z",
    endDate: "2025-07-15T00:00:00Z",
    venue: "Hokejski centar",
    matches: [],
    status: "DRAFT",
    confederationId: "conf_hokej_na_travi_zg",
    createdAt: "2025-05-20T09:15:00Z",
  },
]

// Helper functions
export function getTournamentsByConfederationId(confId: string): Tournament[] {
  return tournaments.filter((t) => t.confederationId === confId)
}

export function getTournamentById(id: string): Tournament | undefined {
  return tournaments.find((t) => t.id === id)
}

// Tournament generation functions
// Helper function to generate tournament matches based on format
export function generateTournamentMatches(tournament: Tournament): TournamentMatch[] {
  switch (tournament.format) {
    case "ROUND_ROBIN":
      return generateRoundRobinMatches(tournament)
    case "SINGLE_ELIMINATION":
      return generateSingleEliminationMatches(tournament)
    case "DOUBLE_ELIMINATION":
      return generateDoubleEliminationMatches(tournament)
    case "GROUP_KNOCKOUT":
      return generateGroupKnockoutMatches(tournament)
    default:
      return []
  }
}

// Generate round-robin matches (everyone plays against everyone)
function generateRoundRobinMatches(tournament: Tournament): TournamentMatch[] {
  const { id: tournamentId, competitorIds, venue, startDate, endDate } = tournament
  const matches: TournamentMatch[] = []

  if (competitorIds.length < 2) return matches

  // Calculate total number of rounds
  const totalRounds = competitorIds.length - 1

  // Calculate matches per round
  const matchesPerRound = Math.floor(competitorIds.length / 2)

  // Calculate days between start and end date
  const start = new Date(startDate)
  const end = new Date(endDate)
  const daysBetween = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))

  // Calculate days between rounds
  const daysBetweenRounds = Math.max(1, Math.floor(daysBetween / totalRounds))

  // Create a copy of competitors array
  const competitors = [...competitorIds]

  // Round robin algorithm (circle method)
  for (let round = 0; round < totalRounds; round++) {
    // Calculate date for this round
    const roundDate = new Date(start)
    roundDate.setDate(start.getDate() + round * daysBetweenRounds)

    // First competitor stays fixed, others rotate
    const firstCompetitor = competitors[0]

    for (let match = 0; match < matchesPerRound; match++) {
      // Calculate the pairs
      const homeIndex = match === 0 ? 0 : match
      const awayIndex = competitorIds.length - 1 - match

      // Create match with alternating home/away
      const isEvenRound = round % 2 === 0
      const homeCompetitorId = isEvenRound ? competitors[homeIndex] : competitors[awayIndex]
      const awayCompetitorId = isEvenRound ? competitors[awayIndex] : competitors[homeIndex]

      // Skip if same team (can happen with odd number of teams)
      if (homeCompetitorId === awayCompetitorId) continue

      // Calculate match time (spread throughout the day)
      const matchTime = new Date(roundDate)
      matchTime.setHours(12 + match, 0, 0)

      matches.push({
        id: uuidv4(),
        tournamentId,
        round: round + 1,
        homeCompetitorId,
        awayCompetitorId,
        date: matchTime.toISOString(),
        venue,
        status: "SCHEDULED",
      })
    }

    // Rotate competitors (except the first one)
    const lastCompetitor = competitors.pop()
    if (lastCompetitor) {
      competitors.splice(1, 0, lastCompetitor)
    }
  }

  return matches
}

// Generate single elimination tournament matches
function generateSingleEliminationMatches(tournament: Tournament): TournamentMatch[] {
  const { id: tournamentId, competitorIds, venue, startDate, endDate } = tournament
  const matches: TournamentMatch[] = []

  if (competitorIds.length < 2) return matches

  // Calculate the number of rounds needed
  const numTeams = competitorIds.length
  const numRounds = Math.ceil(Math.log2(numTeams))
  const totalMatches = Math.pow(2, numRounds) - 1

  // Calculate days between start and end date
  const start = new Date(startDate)
  const end = new Date(endDate)
  const daysBetween = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))

  // Calculate days between rounds
  const daysBetweenRounds = Math.max(1, Math.floor(daysBetween / numRounds))

  // Create a shuffled copy of competitors array
  const shuffledCompetitors = [...competitorIds].sort(() => Math.random() - 0.5)

  // Calculate number of byes needed
  const perfectBracketSize = Math.pow(2, numRounds)
  const numByes = perfectBracketSize - numTeams

  // Create first round matches with byes
  const firstRoundMatches = []
  let matchNumber = 1

  for (let i = 0; i < perfectBracketSize / 2; i++) {
    const homeIndex = i
    const awayIndex = perfectBracketSize - 1 - i

    const homeCompetitorId = homeIndex < shuffledCompetitors.length ? shuffledCompetitors[homeIndex] : ""
    const awayCompetitorId = awayIndex < shuffledCompetitors.length ? shuffledCompetitors[awayIndex] : ""

    // Skip creating matches where both teams are empty (byes)
    if (!homeCompetitorId && !awayCompetitorId) continue

    // Calculate match date
    const matchDate = new Date(start)
    matchDate.setHours(12 + (i % 4), 0, 0)

    const match: TournamentMatch = {
      id: uuidv4(),
      tournamentId,
      round: 1,
      homeCompetitorId: homeCompetitorId || "",
      awayCompetitorId: awayCompetitorId || "",
      date: matchDate.toISOString(),
      venue,
      status: "SCHEDULED",
      matchNumber,
    }

    firstRoundMatches.push(match)
    matchNumber++
  }

  matches.push(...firstRoundMatches)

  // Create subsequent rounds
  let currentRoundMatches = firstRoundMatches

  for (let round = 2; round <= numRounds; round++) {
    const roundDate = new Date(start)
    roundDate.setDate(start.getDate() + (round - 1) * daysBetweenRounds)

    const nextRoundMatches = []

    for (let i = 0; i < currentRoundMatches.length / 2; i++) {
      const matchDate = new Date(roundDate)
      matchDate.setHours(14 + i, 0, 0)

      const match: TournamentMatch = {
        id: uuidv4(),
        tournamentId,
        round,
        homeCompetitorId: "",
        awayCompetitorId: "",
        date: matchDate.toISOString(),
        venue,
        status: "SCHEDULED",
        matchNumber,
      }

      // Link previous matches to this one
      const firstPrevMatch = currentRoundMatches[i * 2]
      const secondPrevMatch = currentRoundMatches[i * 2 + 1]

      if (firstPrevMatch) {
        firstPrevMatch.nextMatchId = match.id
        firstPrevMatch.nextMatchPosition = "home"
      }

      if (secondPrevMatch) {
        secondPrevMatch.nextMatchId = match.id
        secondPrevMatch.nextMatchPosition = "away"
      }

      nextRoundMatches.push(match)
      matchNumber++
    }

    matches.push(...nextRoundMatches)
    currentRoundMatches = nextRoundMatches
  }

  return matches
}

// Generate double elimination tournament matches
function generateDoubleEliminationMatches(tournament: Tournament): TournamentMatch[] {
  const { id: tournamentId, competitorIds, venue, startDate, endDate } = tournament
  const matches: TournamentMatch[] = []

  if (competitorIds.length < 2) return matches

  // Calculate the number of rounds needed for winners bracket
  const numTeams = competitorIds.length
  const numWinnerRounds = Math.ceil(Math.log2(numTeams))

  // Calculate days between start and end date
  const start = new Date(startDate)
  const end = new Date(endDate)
  const daysBetween = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))

  // Calculate days between rounds (we have more rounds in double elimination)
  const totalRounds = numWinnerRounds * 2
  const daysBetweenRounds = Math.max(1, Math.floor(daysBetween / totalRounds))

  // Create a shuffled copy of competitors array
  const shuffledCompetitors = [...competitorIds].sort(() => Math.random() - 0.5)

  // Calculate number of byes needed
  const perfectBracketSize = Math.pow(2, numWinnerRounds)
  const numByes = perfectBracketSize - numTeams

  // First, generate the winners bracket (similar to single elimination)
  const winnersBracket = generateSingleEliminationMatches({
    ...tournament,
    competitorIds: shuffledCompetitors,
  })

  // Mark all matches as winners bracket
  winnersBracket.forEach((match) => {
    match.id = uuidv4() // Generate new IDs to avoid conflicts
  })

  // Add winners bracket matches to the result
  matches.push(...winnersBracket)

  // For simplicity in this implementation, we'll just add some placeholder losers bracket matches
  // In a real implementation, you would need to properly link the losers bracket to the winners bracket

  // Add a few losers bracket matches as placeholders
  for (let i = 0; i < Math.min(4, numTeams / 2); i++) {
    const loserMatchDate = new Date(start)
    loserMatchDate.setDate(start.getDate() + (numWinnerRounds + i) * daysBetweenRounds)
    loserMatchDate.setHours(14 + i, 0, 0)

    matches.push({
      id: uuidv4(),
      tournamentId,
      round: numWinnerRounds + 1, // Losers bracket starts after winners bracket
      homeCompetitorId: "",
      awayCompetitorId: "",
      date: loserMatchDate.toISOString(),
      venue,
      status: "SCHEDULED",
    })
  }

  // Add final match (winners bracket champion vs losers bracket champion)
  const finalMatchDate = new Date(end)
  finalMatchDate.setHours(18, 0, 0)

  matches.push({
    id: uuidv4(),
    tournamentId,
    round: totalRounds,
    homeCompetitorId: "",
    awayCompetitorId: "",
    date: finalMatchDate.toISOString(),
    venue,
    status: "SCHEDULED",
  })

  return matches
}

// Generate group stage + knockout matches
function generateGroupKnockoutMatches(tournament: Tournament): TournamentMatch[] {
  const { id: tournamentId, competitorIds, venue, startDate, endDate } = tournament
  const matches: TournamentMatch[] = []

  if (competitorIds.length < 4) return matches

  // Shuffle competitors
  const shuffledCompetitors = [...competitorIds].sort(() => Math.random() - 0.5)

  // Determine number of groups (default to 2)
  const numGroups = 2
  const teamsPerGroup = Math.ceil(shuffledCompetitors.length / numGroups)

  // Split competitors into groups
  const groups: string[][] = []

  for (let i = 0; i < numGroups; i++) {
    const groupStart = i * teamsPerGroup
    const groupEnd = Math.min(groupStart + teamsPerGroup, shuffledCompetitors.length)
    groups.push(shuffledCompetitors.slice(groupStart, groupEnd))
  }

  // Calculate days between start and end date
  const start = new Date(startDate)
  const end = new Date(endDate)
  const daysBetween = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))

  // Allocate 2/3 of the time for group stage, 1/3 for knockout
  const groupStageDays = Math.floor((daysBetween * 2) / 3)
  const knockoutDays = daysBetween - groupStageDays

  // Generate group stage matches (round robin within each group)
  let currentDay = 0

  for (let groupIndex = 0; groupIndex < groups.length; groupIndex++) {
    const group = groups[groupIndex]

    // Skip empty groups
    if (group.length < 2) continue

    // Generate round robin matches for this group
    const groupMatches = generateRoundRobinMatches({
      ...tournament,
      competitorIds: group,
      startDate: new Date(start.getTime() + currentDay * 24 * 60 * 60 * 1000).toISOString(),
      endDate: new Date(
        start.getTime() + (currentDay + groupStageDays / numGroups) * 24 * 60 * 60 * 1000,
      ).toISOString(),
    })

    // Add group information to matches
    groupMatches.forEach((match) => {
      match.id = uuidv4() // Generate new IDs to avoid conflicts
    })

    matches.push(...groupMatches)

    // Move to next time slot for the next group
    currentDay += groupStageDays / numGroups
  }

  // Generate knockout stage matches (assuming top 2 from each group advance)
  const knockoutStart = new Date(start.getTime() + groupStageDays * 24 * 60 * 60 * 1000)

  // Semi-finals (A1 vs B2, B1 vs A2)
  const semiFinalDate1 = new Date(knockoutStart)
  semiFinalDate1.setHours(18, 0, 0)

  matches.push({
    id: uuidv4(),
    tournamentId,
    round: 2, // Semi-final
    homeCompetitorId: "", // Will be filled with A1
    awayCompetitorId: "", // Will be filled with B2
    date: semiFinalDate1.toISOString(),
    venue,
    status: "SCHEDULED",
  })

  const semiFinalDate2 = new Date(knockoutStart)
  semiFinalDate2.setDate(knockoutStart.getDate() + 1)
  semiFinalDate2.setHours(18, 0, 0)

  matches.push({
    id: uuidv4(),
    tournamentId,
    round: 2, // Semi-final
    homeCompetitorId: "", // Will be filled with B1
    awayCompetitorId: "", // Will be filled with A2
    date: semiFinalDate2.toISOString(),
    venue,
    status: "SCHEDULED",
  })

  // Final
  const finalDate = new Date(end)
  finalDate.setHours(20, 0, 0)

  matches.push({
    id: uuidv4(),
    tournamentId,
    round: 3, // Final
    homeCompetitorId: "", // Will be filled with SF1 winner
    awayCompetitorId: "", // Will be filled with SF2 winner
    date: finalDate.toISOString(),
    venue,
    status: "SCHEDULED",
  })

  return matches
}

// Random tournament name generator
const adjectives = [
  "Ljetni",
  "Zimski",
  "Proljetni",
  "Jesenski",
  "Godišnji",
  "Tradicionalni",
  "Memorijalni",
  "Prijateljski",
  "Međunarodni",
  "Regionalni",
  "Gradski",
  "Državni",
  "Otvoreni",
  "Zatvoreni",
  "Profesionalni",
  "Amaterski",
  "Juniorski",
  "Seniorski",
  "Veteranski",
]

const nouns = ["Kup", "Turnir", "Prvenstvo", "Liga", "Masters", "Challenge", "Trophy", "Open", "Championship", "Series"]

const locations = [
  "Zagreba",
  "Hrvatske",
  "Jadrana",
  "Dalmacije",
  "Slavonije",
  "Istre",
  "Zagorja",
  "Međimurja",
  "Primorja",
  "Podravine",
]

export function generateRandomTournamentName(): string {
  const adjective = adjectives[Math.floor(Math.random() * adjectives.length)]
  const noun = nouns[Math.floor(Math.random() * nouns.length)]
  const location = locations[Math.floor(Math.random() * locations.length)]

  return `${adjective} ${noun} ${location}`
}

// Format display names
export const formatDisplayNames: Record<TournamentFormat, string> = {
  ROUND_ROBIN: "Liga (svatko sa svakim)",
  SINGLE_ELIMINATION: "Jedno ispadanje",
  DOUBLE_ELIMINATION: "Dvaput ispadanje",
  GROUP_KNOCKOUT: "Grupe + nokaut",
}

// Status display names and colors
export const statusDisplayInfo: Record<Tournament["status"], { name: string; color: string }> = {
  DRAFT: { name: "Skica", color: "bg-slate-100 text-slate-800 border-slate-200" },
  ACTIVE: { name: "Aktivan", color: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  COMPLETED: { name: "Završen", color: "bg-blue-100 text-blue-800 border-blue-200" },
  CANCELLED: { name: "Otkazan", color: "bg-rose-100 text-rose-800 border-rose-200" },
}
